/**
 * Clase VentaDAO que implementa la interfaz GenericDAO para gestionar
 * operaciones CRUD sobre objetos de tipo Venta en la base de datos.
 */
package tienda.dao;

import tienda.Model.Pedidos.Pedido;
import tienda.Model.Ventas.Venta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO implements GenericDAO<Venta, Integer> {

    /**
     * Inserta un objeto Venta en la base de datos.
     *
     * @param obj El objeto Venta a insertar.
     */
    @Override
    public void insertar(Venta obj) {
        return;
    }

    /**
     * Obtiene un objeto Venta de la base de datos por su ID.
     *
     * @param id El ID del objeto Venta a obtener.
     * @return El objeto Venta correspondiente al ID, o null si no se encuentra.
     */
    @Override
    public Venta obtenerPorId(Integer id) {
        return null;
    }

    /**
     * Obtiene un objeto Venta de la base de datos por su número de pedido.
     *
     * @param numeroPedido El número de pedido del objeto Venta a obtener.
     * @return El objeto Venta correspondiente al número de pedido, o null si no se encuentra.
     */
    public Venta obtenerPorNumeroPedido(Integer numeroPedido) {
        // SQL para obtener una venta por su número de pedido
        String sql = "SELECT * FROM Venta WHERE numeroPedido = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numeroPedido);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Obtiene todos los objetos Venta de la base de datos.
     *
     * @return Una lista de todos los objetos Venta.
     */
    @Override
    public List<Venta> obtenerTodos() {
        List<Venta> ventas = new ArrayList<>();
        String sql = "SELECT * FROM Venta";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Venta venta = construirDesdeResultSet(rs);
                ventas.add(venta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ventas;
    }

    /**
     * Actualiza un objeto Venta en la base de datos.
     *
     * @param obj El objeto Venta a actualizar.
     */
    @Override
    public void actualizar(Venta obj) {
        return;
    }

    /**
     * Elimina un objeto Venta de la base de datos por su ID.
     *
     * @param id El ID del objeto Venta a eliminar.
     */
    @Override
    public void eliminar(Integer id) {
        // Implementar más tarde
    }

    /**
     * Elimina un objeto Venta de la base de datos por su número de pedido.
     *
     * @param numeroPedido El número de pedido del objeto Venta a eliminar.
     */
    public void eliminar(int numeroPedido) {
        return;
    }

    /**
     * Construye un objeto Venta a partir de un ResultSet.
     *
     * @param rs El ResultSet que contiene los datos de la Venta.
     * @return Un objeto Venta construido a partir del ResultSet.
     * @throws SQLException Si ocurre un error al acceder a los datos del ResultSet.
     */
    @Override
    public Venta construirDesdeResultSet(ResultSet rs) throws SQLException {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        return new Venta(pedidos);
    }
}
