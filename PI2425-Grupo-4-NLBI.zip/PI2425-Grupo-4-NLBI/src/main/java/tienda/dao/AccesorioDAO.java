package tienda.dao;

import tienda.Model.Articulos.*;
import tienda.Model.Catalogo.Material;
import tienda.Util.Enums.TipoAccesorio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccesorioDAO implements GenericDAO<Accesorio, Integer> {

    /**
     * Metodo para insertar un accesorio en la base de datos.
     *
     * @param accesorio El accesorio a insertar.
     * */
    @Override
    public void insertar(Accesorio accesorio) {
        try(Connection conn = DBUtil.getConnection()){
            // Inserta primero el artículo base
            ArticuloDAO Adao = new ArticuloDAO();
            Adao.insertar(accesorio);

            // Inserta en la tabla específica de accesorios
            String sql = "INSERT INTO accesorio (cod_art, estilo, personalizado, " +
                    "tipo_cierre_bolso, capacidad, talla_zapato, tipo_suela, " +
                    "tipo_accesorio) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Atributos comunes
            pstmt.setInt(1, accesorio.getCodigoArticulo());
            pstmt.setString(2, accesorio.getEstilo());
            pstmt.setBoolean(3, accesorio.isEsPersonalizado());

            // Atributos específicos según el tipo de accesorio
            if (accesorio instanceof Bolso) {
                pstmt.setString(4, ((Bolso) accesorio).getTipoCierre());
                pstmt.setInt(5, ((Bolso) accesorio).getCapacidad());
                pstmt.setNull(6, java.sql.Types.INTEGER);
                pstmt.setNull(7, java.sql.Types.VARCHAR);
                pstmt.setString(8, "Bolso");

            } else if (accesorio instanceof Zapato) {
                pstmt.setNull(4, java.sql.Types.VARCHAR);
                pstmt.setNull(5, java.sql.Types.INTEGER);
                pstmt.setString(6, ((Zapato) accesorio).getTipoSuela());
                pstmt.setInt(7, ((Zapato) accesorio).getTallaZapato());
                pstmt.setString(8, "Zapato");
            } else {
                pstmt.setNull(4, java.sql.Types.VARCHAR);
                pstmt.setNull(5, java.sql.Types.INTEGER);
                pstmt.setNull(6, java.sql.Types.INTEGER);
                pstmt.setNull(7, java.sql.Types.VARCHAR);
                pstmt.setString(4, "Accesorio");
            }

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    /**
     * Metodo para actualizar un accesorio en la base de datos.
     *
     * @param accesorio El accesorio a actualizar.
     * */
    @Override
    public void actualizar(Accesorio accesorio) {
        try(Connection conn = DBUtil.getConnection()){
            ArticuloDAO Adao = new ArticuloDAO();
            Adao.insertar(accesorio);

            String sql = "UPDATE accesorio SET estilo = ?, personalizado = ?, " +
                    "tipo_cierre_bolso = ?, capacidad = ?, talla_zapato = ?, tipo_suela = ?," +
                    " tipo_accesorio = ? WHERE cod_art = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Atributos comunes
            pstmt.setInt(1, accesorio.getCodigoArticulo());
            pstmt.setString(2, accesorio.getEstilo());
            pstmt.setBoolean(3, accesorio.isEsPersonalizado());

            // Atributos específicos según el tipo de accesorio
            if (accesorio instanceof Bolso) {
                pstmt.setString(4, ((Bolso) accesorio).getTipoCierre());
                pstmt.setInt(5, ((Bolso) accesorio).getCapacidad());
                pstmt.setNull(6, java.sql.Types.INTEGER);
                pstmt.setNull(7, java.sql.Types.VARCHAR);
                pstmt.setString(8, "Bolso");

            } else if (accesorio instanceof Zapato) {
                pstmt.setNull(4, java.sql.Types.VARCHAR);
                pstmt.setNull(5, java.sql.Types.INTEGER);
                pstmt.setString(6, ((Zapato) accesorio).getTipoSuela());
                pstmt.setInt(7, ((Zapato) accesorio).getTallaZapato());
                pstmt.setString(8, "Zapato");
            } else {
                pstmt.setNull(4, java.sql.Types.VARCHAR);
                pstmt.setNull(5, java.sql.Types.INTEGER);
                pstmt.setNull(6, java.sql.Types.INTEGER);
                pstmt.setNull(7, java.sql.Types.VARCHAR);
                pstmt.setString(4, "Accesorio");
            }

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    /**
     * Metodo para eliminar un accesorio de la base de datos.
     *
     * @param id El id del accesorio a eliminar.
     * */
    @Override
    public void eliminar(Integer id) {

        ArticuloDAO Adao = new ArticuloDAO();
        Adao.eliminar(id);

        String sql = "DELETE FROM accesorio WHERE cod_art = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * Metodo para obtener un accesorio por su id.
     *
     * @param id El id del accesorio a obtener.
     * @return El accesorio con el id especificado.
     * */
    @Override
    public Accesorio obtenerPorId(Integer id) {
        try (Connection conn = DBUtil.getConnection()) {
            // Muestra los datos del accesorio elegido.
            String sql = "SELECT * FROM accesorio, articulo WHERE accesorio.cod_art = " +
                    "articulo.cod_art AND accesorio.cod_art = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return construirDesdeResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Metodo para obtener todos los accesorios de la base de datos.
     *
     * @return Una lista con todos los accesorios.
     * */
    @Override
    public List<Accesorio> obtenerTodos() {
        List<Accesorio> accesorios = new ArrayList<>();
        String sql = "SELECT * FROM accesorio, articulo WHERE accesorio.cod_art = " +
                "articulo.cod_art";

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            // Mientras haya resultados, los añade a la lista.
            while (rs.next()) {
                accesorios.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return accesorios;
    }

    /**
     * Metodo para obtener todos los accesorios de un tipo especifico.
     *
     * @param tipo El tipo de accesorio a obtener.
     * @return Una lista con todos los accesorios del tipo especificado.
     * */
   public List<Accesorio> obtenerPorTipo(String tipo) {
       // Muestra los datos del accesorio elegido por tipo.
       List<Accesorio> accesoriosL = new ArrayList<>();

       String sql = "SELECT * FROM accesorio, articulo WHERE accesorio.cod_art = " +
               "articulo.cod_art AND tipo_accesorio = ?";

       try (Connection conn = DBUtil.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
           pstmt.setString(1, tipo);
           ResultSet rs = pstmt.executeQuery();
           while (rs.next()) {
               accesoriosL.add(construirDesdeResultSet(rs));
           }
       } catch (SQLException e) {
           e.printStackTrace();

       }
       return accesoriosL;
   }

    @Override
    public Accesorio construirDesdeResultSet(ResultSet rs) throws SQLException {

        MaterialDAO materialDAO = new MaterialDAO();

        // Obtiene datos comunes desde el ResultSet
        Material material = materialDAO.obtenerPorId(rs.getInt("material"));
        String nombre = rs.getString("nombre");
        String imagen = rs.getString("imagen");
        float precio = rs.getFloat("precio");
        String marca = rs.getString("marca");
        String descripcion = rs.getString("descripcion");
        boolean activo = rs.getBoolean("activo");
        String color = rs.getString("color");
        int cod_art = rs.getInt("cod_art");

        // Datos específicos del accesorio
        String estilo = rs.getString("estilo");
        boolean esPersonalizado = rs.getBoolean("personalizado");
        String tipoaccesorioo = rs.getString("tipo_accesorio");

        TipoAccesorio tipoAccesorio = TipoAccesorio.valueOf(tipoaccesorioo);

        // Crea la instancia según el tipo
        if (tipoAccesorio == TipoAccesorio.bolso) {
            String tipoCierre = rs.getString("tipo_cierre_bolso");
            int capacidad = rs.getInt("capacidad");
            return new Bolso(cod_art,nombre,precio,marca,descripcion,imagen,activo,color,material
                    ,estilo,esPersonalizado,tipoCierre,capacidad,tipoAccesorio);

        } else if (tipoAccesorio == TipoAccesorio.zapato) {
            int tallaZapatos = rs.getInt("talla_zapato");
            String tipoSuela = rs.getString("tipo_suela");

            return new Zapato(cod_art,nombre,precio,marca,descripcion,imagen,activo,
                    color,material,estilo,esPersonalizado,tallaZapatos,tipoSuela,tipoAccesorio);
        } else {
            return new Accesorio(cod_art,nombre,precio,marca,descripcion,imagen,activo,color,material
                    ,estilo,esPersonalizado);
        }

    }
}
