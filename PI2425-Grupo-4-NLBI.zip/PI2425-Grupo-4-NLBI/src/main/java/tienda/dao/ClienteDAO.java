package tienda.dao;


import tienda.Model.Clientes.Cliente;
import tienda.Model.Pedidos.Metodo_Pago;
import tienda.Model.Pedidos.Pedido;


import java.sql.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO implements GenericDAO <Cliente, String> {


    /**
     * Metodo para insertar un cliente en la base de datos
     *
     * @param cliente Cliente a insertar
     */
    @Override
    public void insertar(Cliente cliente) {
        String sql;
        sql = "INSERT INTO cliente (DNI, nombre, apellidos, telefono, f_nacimiento," +
                " direccion, email, activo, pass, saldo_cuenta, " +
                "num_pedidos, dir_envio, tarjeta_fidelizacion, m_pago) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cliente.getDni());
            stmt.setString(2, cliente.getApellidos());
            stmt.setString(3, cliente.getNombre());
            stmt.setInt(4, cliente.getTelefono());
            stmt.setString(5, cliente.getDireccion());
            stmt.setString(6, cliente.getEmail());
            stmt.setBoolean(7, cliente.isActivo());
            stmt.setString(8, cliente.getPass());
            stmt.setDate(9, Date.valueOf(cliente.getFechaNacimiento()));
            stmt.setInt(10, cliente.getNumeroPedidos());
            stmt.setBoolean(11, cliente.isTieneTarjetaFidelizacion());
            stmt.setString(12, cliente.getDireccionEnvio());
            stmt.setInt(13, cliente.getMetodoPago().getCodigo());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para eliminar un cliente de la base de datos
     *
     * @param DNI DNI del cliente a eliminar
     * */
    @Override
    public void eliminar(String DNI) {
        String sql = "DELETE FROM cliente WHERE DNI = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, DNI);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para actualizar un cliente en la base de datos
     *
     * @param cliente Cliente a actualizar
     */
    @Override
    public void actualizar(Cliente cliente) {
        String sql;
        sql = "UPDATE cliente SET DNI = ?, nombre = ?, apellidos = ?, telefono = ?," +
                " f_nacimiento = ?, direccion = ?, email = ?, activo = ?, pass = ?," +
                " saldo_cuenta = ?, num_pedidos = ?, dir_envio = ?, tarjeta_fidelizacion = ?, m_pago = ? WHERE DNI = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cliente.getDni());
            stmt.setString(2, cliente.getApellidos());
            stmt.setString(3, cliente.getNombre());
            stmt.setInt(4, cliente.getTelefono());
            stmt.setString(5, cliente.getDireccion());
            stmt.setString(6, cliente.getEmail());
            stmt.setBoolean(7, cliente.isActivo());
            stmt.setString(8, cliente.getPass());
            stmt.setDate(9, Date.valueOf(cliente.getFechaNacimiento()));
            stmt.setInt(10, cliente.getNumeroPedidos());
            stmt.setBoolean(11, cliente.isTieneTarjetaFidelizacion());
            stmt.setString(12, cliente.getDireccionEnvio());
            stmt.setInt(13, cliente.getMetodoPago().getCodigo());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para obtener un cliente de la base de datos por id
     *
     * @param id DNI del cliente a obtener
     * */
    @Override
    public Cliente obtenerPorId(String id) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement pstmt = conn.prepareStatement
                    ("SELECT * FROM cliente WHERE DNI = ?");
            pstmt.setString(1, id);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return construirDesdeResultSet(rs);
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    /**
     * Metodo para obtener todos los clientes de la base de datos
     *
     * @return Lista de clientes
     */
    @Override
    public List<Cliente> obtenerTodos() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM cliente";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                clientes.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return clientes;
    }

    /**
     * Metodo para obtener todos los clientes de la base de datos
     *
     * @return Lista de clientes
     */
    public List<Cliente> obtenerTodosClientes() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM cliente";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                clientes.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }

    /**
     * Metodo para autenticar un cliente
     *
     * @param Email Email del cliente
     * @param pass Contraseña del cliente
     * */
    public Cliente autenticarCliente(String Email, String pass) {
        String sql = "SELECT * FROM cliente WHERE Email = ? AND pass = ?";
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, Email);
            stmt.setString(2, pass);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener un cliente de la base de datos por email
     *
     * @param email Email del cliente a obtener
     * */
    public Cliente obtenerPorEmail(String email) {
        String sql = "SELECT * FROM cliente WHERE email = ?";
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener un metodo de pago de la base de datos por codigo
     *
     * @param codigo  Del metodo de pago a obtener
     * */
    public Metodo_Pago obtenerMetodoPagoPorCodigo(int codigo) {
        String sql = "SELECT * FROM metodo_pago WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Metodo_Pago(
                            rs.getInt("codigo"),
                            rs.getString("descripcion")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Metodo para crear un cliente desde un ResultSet
     *
     * @param rs ResultSet a partir del cual se crea el cliente
     * @return Cliente creado
     * */
    public Cliente construirDesdeResultSet(ResultSet rs) throws SQLException {
        PedidoDAO peDAO = new PedidoDAO();
        Metodo_PagoDAO metodoPagoDAO = new Metodo_PagoDAO();

        return new Cliente(
                rs.getString("DNI"),
                rs.getString("Nombre"),
                rs.getString("Apellidos"),
                rs.getInt("Telefono"),
                rs.getString("Direccion"),
                rs.getString("Email"),
                rs.getBoolean("Activo"),
                rs.getString("pass"),
                rs.getDate("f_nacimiento").toLocalDate(),
                rs.getInt("num_pedidos"),
                rs.getBoolean("tarjeta_fidelizacion"),
                rs.getString("dir_envio"),
                metodoPagoDAO.obtenerPorCodigo(rs.getInt("m_pago")),
                new ArrayList<Pedido>()
        );

    }
}
