package tienda.dao;

import tienda.Model.Clientes.Cliente;
import tienda.Model.Pedidos.LineaPedido;
import tienda.Model.Pedidos.Metodo_Pago;
import tienda.Model.Pedidos.Pedido;
import tienda.Util.Enums.EstadoPedido;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO implements GenericDAO<Pedido, Integer>{

    /**
     * Metodo para insertar un pedido en la base de datos
     *
     * @param pedido El pedido a insertar
     * */
    @Override
    public void insertar(Pedido pedido) {
        String sql = "INSERT INTO pedido (numero, fecha, dir_envio, estado, m_pago," +
                "DNI_cliente) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, pedido.getNumeroPedido());
            stmt.setDate(2, new Date(pedido.getFecha().getTime()));
            stmt.setString(3, pedido.getDir_envio());
            stmt.setString(4, "En proceso");
            stmt.setString(6, pedido.getDNI_cliente());
            stmt.setInt(5, pedido.getMetodoPago().getCodigo());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();


        }
    }

    /**
     * Metodo para obtener un pedido en la base de datos
     *
     * @param id El id del pedido a obtener según el DNI del cliente
     * @return El pedido obtenido
     * */
    public Pedido obtenerPedidoActualPorUsuario(String id) {
        String sql = "SELECT * FROM Pedido WHERE DNI_cliente = ? AND estado = 'En proceso'";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1,id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener un pedido en la base de datos
     *
     * @param id El id del pedido a obtener
     * @return El pedido obtenido
     * */
    @Override
    public Pedido obtenerPorId(Integer id) {
        String sql = "SELECT * FROM Pedido WHERE numeroPedido = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener un pedido en la base de datos
     *
     * @param numeroPedido El numero del pedido a obtener
     * @return El pedido obtenido
     * */
    public Pedido obtenerPorNumeroPedido(Integer numeroPedido) {
        String sql = "SELECT * FROM Pedido WHERE numeroPedido = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numeroPedido);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener un pedido en la base de datos
     *
     * @param DNI_cliente El DNI del cliente a obtener sus pedidos
     * @return Los pedidos obtenidos
     * */
    public ArrayList<Pedido> obtenerPedidosPorCliente(String DNI_cliente) {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM pedido WHERE DNI_cliente = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, DNI_cliente);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Pedido pedido = construirDesdeResultSet(rs);
                    pedidos.add(pedido);
                }
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return pedidos;
    }

    /**
     * Metodo para obtener la cantidad de pedidos de un cliente
     *
     * @param DNI_cliente El DNI del cliente a obtener sus pedidos
     * @return La cantidad de pedidos obtenidos
     * */
    public Integer obtenerCantPedidosPorCliente(String DNI_cliente) {
        String sql = "SELECT count(*) FROM pedido WHERE DNI_cliente = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, DNI_cliente);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener todos los pedidos de la base de datos
     *
     * @return Los pedidos obtenidos
     * */
    @Override
    public List<Pedido> obtenerTodos(){
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM Pedido";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Pedido pedido = construirDesdeResultSet(rs);
                pedidos.add(pedido);
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return pedidos;
    }

    /**
     * Metodo para actualizar pedidos de la base de datos
     *
     * @return Los pedidos obtenidos
     * */
    @Override
    public void actualizar(Pedido obj) {
        String sql = "UPDATE pedido SET fecha = ?, dir_envio = ?, estado = ?, m_pago = ? WHERE numero = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, new Date(obj.getFecha().getTime()));
            stmt.setString(2, obj.getDir_envio());
            stmt.setString(3, obj.getEstadoPedido().toString());
            stmt.setString(3, obj.getDNI_cliente());
            stmt.setString(4, obj.getMetodoPago().getDescripcion());
            stmt.setInt(5, obj.getNumeroPedido());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     * Metodo para eliminar un pedido de la base de datos
     *
     * @param id El id del pedido a eliminar
     * */
    @Override
    public void eliminar(Integer id) {
        String sql = "DELETE FROM pedido WHERE numeroPedido = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)){
            stmt.setInt(1,id);
            stmt.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        }

    }

    /**
     * Metodo para construir un pedido desde un ResultSet
     *
     * @param rs El ResultSet a construir el pedido
     * @return El pedido construido
     * */
    @Override
    public Pedido construirDesdeResultSet(ResultSet rs) throws SQLException {
        Metodo_PagoDAO metodoPagoDAO = new Metodo_PagoDAO();

        int numeroPedido = rs.getInt("numero");
        Date fecha = rs.getDate("fecha");
        String dir_envio = rs.getString("dir_envio");
        String DNI_cliente = rs.getString("DNI_cliente");
        Metodo_Pago metodoPago = metodoPagoDAO.obtenerPorDescripcion(rs.getString("m_pago"));
        ArrayList<LineaPedido> lineaPedidos = new ArrayList<>();
        ArrayList<Cliente> clientes = new ArrayList<>();
        String estadoPedido = rs.getString("estado");

        return new Pedido(numeroPedido, fecha, dir_envio, DNI_cliente, metodoPago, lineaPedidos, clientes,estadoPedido);
    }

    /**
     * Metodo para confirmar un pedido en la base de datos
     *
     * @param numeroPedido El numero del pedido confirmado
     * */
    public void confirmarPedido(int numeroPedido) {
        String sql = "UPDATE pedido SET estado = 'confirmado' WHERE numero = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numeroPedido);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
