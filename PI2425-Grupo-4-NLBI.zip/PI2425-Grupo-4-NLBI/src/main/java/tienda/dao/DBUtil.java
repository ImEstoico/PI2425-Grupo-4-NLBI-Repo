package tienda.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

    public static Connection getConnection() throws SQLException {
        try {
            // url de la base de datos con usuario y contraseña
            String URL = "jdbc:mysql://localhost:3306/tienda_ropa";
            String USUARIO = "root";
            String CONTRASENA = "MySQL24-25";
            return DriverManager.getConnection(URL, USUARIO, CONTRASENA);

            //por si da error
        } catch (SQLException e) {
            System.err.println("Error al conectar con la base de datos.");
            throw e;
        }
    }
    // Metodo para cerrar la conexión
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión cerrada correctamente.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

