/**
 * Clase RopaDAO que implementa la interfaz GenericDAO para gestionar
 * operaciones CRUD sobre objetos de tipo Ropa en la base de datos.
 */
package tienda.dao;

import tienda.Model.Articulos.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RopaDAO implements GenericDAO<Ropa, Integer> {

    /**
     * Inserta un objeto Ropa en la base de datos.
     *
     * @param ropa El objeto Ropa a insertar.
     */
    @Override
    public void insertar(Ropa ropa) {
        return;
    }

    /**
     * Obtiene un objeto Ropa de la base de datos por su ID.
     *
     * @param id El ID del objeto Ropa a obtener.
     * @return El objeto Ropa correspondiente al ID, o null si no se encuentra.
     */
    @Override
    public Ropa obtenerPorId(Integer id) {
        String sql = "SELECT * FROM ropa WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Obtiene todos los objetos Ropa de la base de datos.
     *
     * @return Una lista de todos los objetos Ropa.
     */
    @Override
    public List<Ropa> obtenerTodos() {
        List<Ropa> ropas = new ArrayList<>();
        String sql = "SELECT * FROM ropa";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ropas.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ropas;
    }

    /**
     * Actualiza un objeto Ropa en la base de datos.
     *
     * @param ropa El objeto Ropa a actualizar.
     */
    @Override
    public void actualizar(Ropa ropa) {
        // TODO: Implementar este método más adelante
        return;
    }

    /**
     * Elimina un objeto Ropa de la base de datos por su ID.
     *
     * @param id El ID del objeto Ropa a eliminar.
     */
    @Override
    public void eliminar(Integer id) {
        // TODO: Implementar este método más adelante
        return;
    }

    /**
     * Construye un objeto Ropa a partir de un ResultSet.
     *
     * @param rs El ResultSet que contiene los datos de la Ropa.
     * @return Un objeto Ropa construido a partir del ResultSet.
     * @throws SQLException Si ocurre un error al acceder a los datos del ResultSet.
     */
    @Override
    public Ropa construirDesdeResultSet(ResultSet rs) throws SQLException {
        MaterialDAO materialDAO = new MaterialDAO();

        return new Ropa(
                rs.getInt("codigoArticulo"),
                rs.getString("nombre"),
                rs.getFloat("precio"),
                rs.getString("marca"),
                rs.getString("descripcion"),
                rs.getString("imagen"),
                rs.getBoolean("activo"),
                rs.getString("color"),
                materialDAO.obtenerMaterialPorDenominacion(rs.getString("material")),
                rs.getInt("talla"),
                rs.getString("tipoCierre"));
    }
}
