package tienda.dao;

import tienda.Model.Articulos.Articulo;
import tienda.Model.Catalogo.Material;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ArticuloDAO implements GenericDAO<Articulo, Integer> {


    /**
     * Metodo para insertar un nuevo artículo en la base de datos.
     *
     * @param articulo El artículo a insertar.
     * */
    @Override
    public void insertar(Articulo articulo) {

        try (Connection conn = DBUtil.getConnection()){
            String sql = "INSERT INTO articulo (cod_art, nombre, precio, marca," +
                    " descripcion, imagen, activo, color, material) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Atributos comunes
            pstmt.setInt(1, articulo.getCodigoArticulo());
            pstmt.setString(2, articulo.getNombre());
            pstmt.setFloat(3, articulo.getPrecio());
            pstmt.setString(4, articulo.getMarca());
            pstmt.setString(5, articulo.getDescripcion());
            pstmt.setString(6, articulo.getImagen());
            pstmt.setBoolean(8, articulo.isActivo());
            pstmt.setString(7, articulo.getColor());
            pstmt.setString(9, articulo.getMaterial().getDenominacion());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para obtener un artículo por su ID.
     *
     * @param id El ID del artículo a obtener.
     * @return El artículo correspondiente al ID, o null si no se encuentra.
     * */
    public Articulo obtenerPorId(Integer id) {
        String sql = "SELECT * FROM articulo WHERE cod_art = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener todos los artículos de la base de datos.
     *
     *
     * @return El artículo correspondiente al nombre, o null si no se encuentra.
     * */
    @Override
    public List<Articulo> obtenerTodos() {
        List<Articulo> articulos = new ArrayList<>();
        String sql = "SELECT * FROM articulo";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                articulos.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articulos;
    }

    /**
     * Metodo para actualizar un artículo.
     *
     * @param articulo El artículo a actualizar.
     * @return El artículo correspondiente actualizado, o null si no se encuentra.
     * */
    @Override
    public void actualizar(Articulo articulo) {
        try (Connection conn = DBUtil.getConnection()){
            String sql = "UPDATE articulo SET nombre = ?, precio = ?, marca = ?, " +
                    "descripcion = ?, imagen = ?, activo = ?, color = ?, material = ? WHERE cod_art = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Atributos comunes
            pstmt.setString(1, articulo.getNombre());
            pstmt.setFloat(2, articulo.getPrecio());
            pstmt.setString(3, articulo.getMarca());
            pstmt.setString(4, articulo.getDescripcion());
            pstmt.setString(5, articulo.getImagen());
            pstmt.setBoolean(6, articulo.isActivo());
            pstmt.setString(7, articulo.getColor());
            pstmt.setString(8, articulo.getMaterial().getDenominacion());
            pstmt.setInt(9, articulo.getCodigoArticulo());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para eliminar un artículo por su ID.
     *
     * @param id El ID del artículo a eliminar.
     * */
    @Override
    public void eliminar(Integer id) {
        String sql = "DELETE FROM articulo WHERE cod_art = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para obtener un material por su codigo.
     *
     * @param codigo El codigo del material a obtener.
     * @return El material correspondiente al codigo, o null si no se encuentra.
     * */
    public Material obtenerMaterialPorCodigo(Integer codigo) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM material WHERE codigo = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, codigo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Material(
                        rs.getInt("codigo"),
                        rs.getString("denominacion")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener un material por su denominacion.
     *
     * @param denominacion La denominacion del material a obtener.
     * @return El material correspondiente a la denominacion, o null si no se encuentra.
     * */
    public Material obtenerMaterialPorDenominacion(String denominacion) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM material WHERE denominacion = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, denominacion);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Material(
                        rs.getInt("codigo"),
                        rs.getString("denominacion")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para construir un artículo a partir de un ResultSet.
     *
     * @param rs El ResultSet que contiene los datos del artículo.
     * @return El artículo construido a partir del ResultSet.
     * */
    public Articulo construirDesdeResultSet(ResultSet rs) throws SQLException {
        MaterialDAO materialDAO = new MaterialDAO();

        return new Articulo(
                rs.getInt("cod_art")
                , rs.getString("nombre")
                , rs.getFloat("precio")
                , rs.getString("marca")
                , rs.getString("descripcion")
                , rs.getString("imagen")
                , rs.getBoolean("activo")
                , rs.getString("color")
                , materialDAO.obtenerMaterialPorDenominacion(rs.getString("material"))
        );
    }
}