package tienda.dao;

import tienda.Model.Empleados.Empleado;

import java.sql.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAO implements GenericDAO <Empleado, String>{

    /**
     * Metodo para insertar un empleado en la base de datos.
     *
     * @param empleado El empleado a insertar.
     * */
    @Override
    public void insertar(Empleado empleado) {
        String sql = "INSERT INTO empleado (DNI, nombre, apellidos, telefono, f_nacimiento," +
                " direccion, email, activo, tiene_privilegios, pass, dpto)" +
                " values (?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, empleado.getDni());
            stmt.setString(2, empleado.getNombre());
            stmt.setString(3, empleado.getApellidos());
            stmt.setInt(4, empleado.getTelefono());
            stmt.setDate(5, Date.valueOf(empleado.getFechaNacimiento()));
            stmt.setString(6, empleado.getDireccion());
            stmt.setString(7, empleado.getEmail());
            stmt.setBoolean(8, empleado.isActivo());
            stmt.setString(9, empleado.getPass());
            stmt.setBoolean(10, empleado.tienePrivilegios());
            stmt.setInt(11, empleado.getDepartamento().getCodigo());

            int filasAfectadas = stmt.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Se ha insertado el empleado correctamente.");
            } else {
                System.out.println("No se insertó ningún empleado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
   }

    /**
     * Metodo para eliminar un empleado de la base de datos.
     *
     * @param DNI El DNI del empleado a eliminar.
     * */
    @Override
    public void eliminar(String DNI) {
        String sql = "DELETE FROM empleado WHERE DNI = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, DNI);
            int filasAfectadas = stmt.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Se ha eliminado el empleado correctamente.");
            } else {
                System.out.println("No se eliminó ningún empleado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para actualizar un empleado en la base de datos.
     *
     * @param empleado El empleado a actualizar.
     * */
    @Override
    public void actualizar(Empleado empleado) {
        String sql = "UPDATE empleado SET DNI = ?, nombre = ?, apellidos = ?, telefono = ?," +
                " f_nacimiento = ?, direccion = ?, email = ?, activo = ?, pass = ?," +
                " tiene_privilegios = ?, dpto = ? WHERE DNI = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, empleado.getDni());
            stmt.setString(2, empleado.getNombre());
            stmt.setString(3, empleado.getApellidos());
            stmt.setInt(4, empleado.getTelefono());
            stmt.setDate(5, Date.valueOf(empleado.getFechaNacimiento()));
            stmt.setString(6, empleado.getDireccion());
            stmt.setString(7, empleado.getEmail());
            stmt.setBoolean(8, empleado.isActivo());
            stmt.setString(9, empleado.getPass());
            stmt.setBoolean(10, empleado.tienePrivilegios());
            stmt.setInt(11, empleado.getDepartamento().getCodigo());

            int filasAfectadas = stmt.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Se ha insertado el empleado correctamente.");
            } else {
                System.out.println("No se insertó ningún empleado.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Metodo para obtener un empleado de la base de datos por su DNI.
     *
     * @param DNI El DNI del empleado a obtener.
     * @return El empleado con el DNI especificado, o null si no se encuentra.
     * */
    @Override
    public Empleado obtenerPorId(String DNI) {
        String sql = "SELECT * FROM empleado WHERE DNI = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, DNI);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
        return null;
    }

    /**
     * Metodo para obtener todos los empleados de la base de datos.
     *
     * @return Una lista con todos los empleados.
     * */
    @Override
    public List<Empleado>   obtenerTodos() {
        List<Empleado> empleados = new ArrayList<>();
        String sql = "SELECT * FROM empleado";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                empleados.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return empleados;

    }

    /**
     * Metodo para obtener un empleado de la base de datos por su email.
     *
     * @param email El email del empleado a obtener.
     * @return El empleado con el email especificado, o null si no se encuentra.
     * */
    public Empleado obtenerPorEmail(String email) {
        String sql = "SELECT * FROM empleado WHERE email = ?";
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);

        }
        return null;
    }
        /**
         * Metodo para autenticar un empleado en la base de datos.
         *
         * @param Email El email del empleado a autenticar.
         * @param pass La contraseña del empleado a autenticar.
         * @return El empleado autenticado, o null si no se encuentra.
         * */
        public Empleado autenticarEmpleado(String Email, String pass) {
            String sql = "SELECT * FROM empleado WHERE Email = ? AND pass = ?";
            try (Connection conn = DBUtil.getConnection()) {
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, Email);
                stmt.setString(2, pass);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return construirDesdeResultSet(rs);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;
        }

    /**
     * Metodo para construir un empleado a partir de un ResultSet.
     *
     * @param rs El ResultSet con los datos del empleado.
     * @return El empleado construido a partir del ResultSet.
     * */
    public Empleado construirDesdeResultSet(ResultSet rs) throws SQLException {
        return new Empleado(
                rs.getString("DNI"),
                rs.getString("apellidos"),
                rs.getString("nombre"),
                rs.getInt("telefono"),
                rs.getString("direccion"),
                rs.getString("email"),
                rs.getBoolean("activo"),
                rs.getString("pass"),
                rs.getDate("f_nacimiento").toLocalDate(),
                rs.getBoolean("tienePrivilegios"),
                DepartamentoDAO.obtenerDepartamentoPorCodigo(rs.getInt("codigoDepartamento")));
    }
}