package tienda.dao;

import tienda.Model.Catalogo.Material;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MaterialDAO implements GenericDAO<Material, Integer> {
    /**
     * Metodo para insertar un material en la base de datos
     *
     * @param material el material a insertar
     * */
    @Override
    public void insertar(Material material) {
        String sql = "INSERT INTO material (codigo, denominacion) VALUES ( ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, material.getDenominacion());
            stmt.setInt(2, material.getCodigo());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para obtener un material por su id
     *
     * @param id el id del material a obtener
     * @return el material con el id especificado
     * */
    @Override
    public Material obtenerPorId(Integer id) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM material WHERE codigo = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return construirDesdeResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener todos los materiales de la base de datos
     *
     * @return una lista con todos los materiales
     * */
    @Override
    public List<Material> obtenerTodos() {
        List<Material> materiales = new ArrayList<>();
        String sql = "SELECT * FROM material";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                materiales.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return materiales;
    }

    /**
     * Metodo para obtener un material por su denominacion
     *
     * @param denominacion la denominacion del material a obtener
     * @return el material con la denominacion especificada
     * */
    public Material obtenerMaterialPorDenominacion(String denominacion) {
        String sql = "SELECT * FROM material WHERE denominacion = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, denominacion);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para actualizar un material
     *
     * @param material el id del material a obtener
     * @return el material con el id especificado
     * */
    @Override
    public void actualizar(Material material) {
        String sql = "UPDATE libro SET codigo = ?, denominacion = ? WHERE material = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, material.getDenominacion());
            stmt.setInt(2, material.getCodigo());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para eliminar un material
     *
     * @param id el id del material a eliminar
     * */
    @Override
    public void eliminar(Integer id) {
        String sql = "DELETE FROM material WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para construir un material desde un ResultSet
     *
     * @param rs el ResultSet con los datos del material
     * @return el material construido
     * */
    @Override
    public Material construirDesdeResultSet(ResultSet rs) throws SQLException {
        return new Material(
                rs.getInt("Código"),
                rs.getString("Denominación")
        );
    }
}
