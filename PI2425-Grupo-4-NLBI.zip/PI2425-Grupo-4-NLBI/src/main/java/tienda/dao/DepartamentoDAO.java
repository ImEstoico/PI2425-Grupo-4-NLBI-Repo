package tienda.dao;

import tienda.Model.Empleados.Departamento;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartamentoDAO implements GenericDAO<Departamento, Integer> {

    /**
     * Metodo para insertar un nuevo departamento en la base de datos.
     *
     * @param departamento El departamento a insertar.
     * */
    @Override
    public void insertar(Departamento departamento) {
        String sql = "INSERT INTO departamento (codigo, nombre) VALUES (?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, departamento.getCodigo());
            stmt.setString(2, departamento.getNombre());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para actualizar un departamento en la base de datos.
     *
     * @param departamento El departamento a actualizar.
     * */
    @Override
    public void actualizar(Departamento departamento) {
        String sql = "UPDATE departamento SET nombre = ? WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, departamento.getNombre());
            stmt.setInt(2, departamento.getCodigo());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para eliminar un departamento de la base de datos.
     *
     * @param codigo El codigo del departamento a eliminar.
     * */
    @Override
    public void eliminar(Integer codigo) {
        String sql = "DELETE FROM departamento WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, codigo);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para construir un objeto Departamento a partir de un ResultSet.
     *
     * @param rs El ResultSet que contiene los datos del departamento.
     * @return Un objeto Departamento construido a partir del ResultSet.
     * */
    @Override
    public Departamento construirDesdeResultSet(ResultSet rs) throws SQLException {
        return null;
    }

    /**
     * Metodo para obtener un departamento por su ID.
     *
     * @param id El ID del departamento a obtener.
     * @return El departamento correspondiente al ID proporcionado.
     * */
    @Override
    public Departamento obtenerPorId(Integer id) {
        String sql = "SELECT * FROM departamento WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener todos los departamentos de la base de datos.
     *
     * @return Una lista de todos los departamentos.
     * */
    @Override
    public List<Departamento> obtenerTodos () {

        List<Departamento> departamentos = new ArrayList<>();
        String sql = "SELECT * FROM departamento";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                departamentos.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return departamentos;
    }

    /**
     * Metodo para obtener un departamento por su codigo.
     *
     * @param codigo El codigo del departamento a obtener.
     * @return El departamento correspondiente al codigo proporcionado.
     * */
    public static Departamento obtenerDepartamentoPorCodigo(Integer codigo) {
        String sql = "SELECT * FROM departamento WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Departamento(
                            rs.getInt("codigo"),
                            rs.getString("nombre")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}
