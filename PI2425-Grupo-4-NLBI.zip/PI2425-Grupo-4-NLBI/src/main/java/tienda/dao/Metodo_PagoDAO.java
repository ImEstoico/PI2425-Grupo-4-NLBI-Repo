package tienda.dao;

import tienda.Model.Pedidos.Metodo_Pago;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Metodo_PagoDAO implements GenericDAO<Metodo_Pago, Integer> {

    /**
     * Metodo para insertar un nuevo metodo de pago en la base de datos
     *
     * @param metodo_pago objeto de tipo Metodo_Pago que contiene la informacion del nuevo metodo de pago
     * */
    @Override
    public void insertar(Metodo_Pago metodo_pago) {

        String sql = "INSERT INTO metodo_pago (codigo, descripcion) VALUES (?, ?)\")";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, metodo_pago.getCodigo());
            stmt.setString(2, metodo_pago.getDescripcion());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    /**
     * Metodo para actualizar un metodo de pago existente en la base de datos
     *
     * @param metodo_pago objeto de tipo Metodo_Pago que contiene la informacion del metodo de pago a actualizar
     * */
    @Override
    public void actualizar(Metodo_Pago metodo_pago) {

        String sql = "UPDATE metodo_pago SET descripcion = ? WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, metodo_pago.getDescripcion());
            stmt.setInt(2, metodo_pago.getCodigo());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para eliminar un metodo de pago existente en la base de datos
     *
     * @param id entero que representa el codigo del metodo de pago a eliminar
     * */
    @Override
    public void eliminar(Integer id) {
        String sql = "DELETE FROM metodo_pago WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para obtener un metodo de pago existente en la base de datos
     *
     * @param id entero que representa el codigo del metodo de pago a obtener
     * @return objeto de tipo Metodo_Pago que contiene la informacion del metodo de pago obtenido
     * */
    @Override
    public Metodo_Pago obtenerPorId(Integer id) {

        String sql = "SELECT * FROM metodo_pago WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * Metodo para obtener todos los metodos de pago existentes en la base de datos
     *
     * @return lista de objetos de tipo Metodo_Pago que contiene la informacion de todos los metodos de pago obtenidos
     * */
    @Override
    public List<Metodo_Pago> obtenerTodos() {
        return List.of();
    }

    /**
     * Metodo para obtener un metodo de pago existente en la base de datos
     *
     * @param codigo entero que representa el codigo del metodo de pago a obtener
     * @return objeto de tipo Metodo_Pago que contiene la informacion del metodo de pago obtenido
     * */
    public Metodo_Pago obtenerPorCodigo(int codigo) {
        String sql = "SELECT * FROM metodo_pago WHERE codigo = ?";
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para obtener todos los metodos de pago existentes en la base de datos
     *
     * @return lista de objetos de tipo Metodo_Pago que contiene la informacion de todos los metodos de pago obtenidos
     * */
    public List<Metodo_Pago> obtenerTodosMetodosPago() {
        List<Metodo_Pago> metodos_pago = new ArrayList<>();
        String sql = "SELECT * FROM metodo_pago";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                metodos_pago.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return metodos_pago;
    }


    /**
     * Metodo para obtener un metodo de pago existente en la base de datos
     *
     * @param descripcion cadena que representa la descripcion del metodo de pago a obtener
     * @return objeto de tipo Metodo_Pago que contiene la informacion del metodo de pago obtenido
     * */
    public Metodo_Pago obtenerPorDescripcion(String descripcion) {
        String sql = "SELECT * FROM metodo_pago WHERE descripcion = ?";
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, descripcion);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Metodo para construir un objeto de tipo Metodo_Pago a partir de un ResultSet
     *
     * @param rs objeto de tipo ResultSet que contiene la informacion del metodo de pago
     * @return objeto de tipo Metodo_Pago que contiene la informacion del metodo de pago obtenido
     * */
    @Override
    public Metodo_Pago construirDesdeResultSet(ResultSet rs) throws SQLException {
        return new Metodo_Pago(
                rs.getInt("codigo"),
                rs.getString("descripcion"));
    }
}
