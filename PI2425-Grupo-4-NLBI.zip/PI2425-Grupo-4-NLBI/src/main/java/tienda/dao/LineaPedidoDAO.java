package tienda.dao;

import tienda.Model.Articulos.Articulo;
import tienda.Model.Pedidos.LineaPedido;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LineaPedidoDAO implements GenericDAO<LineaPedido, Integer> {

    /**
     * Metodo para insertar una nueva línea de pedido en la base de datos.
     *
     * @param obj Objeto LineaPedido que contiene la información de la línea de pedido a insertar.
     * */
    @Override
    public void insertar(LineaPedido obj) {
        String sql = "INSERT INTO linea_pedido (num_pedido, cod_art) VALUES (?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, obj.getNum_pedido());
            stmt.setInt(2, obj.getArticulo().getCodigoArticulo());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    /**
     * Metodo para actualizar una línea de pedido en la base de datos.
     *
     * @param obj Objeto LineaPedido que contiene la información de la línea de pedido a actualizar.
     * */
    @Override
    public void actualizar(LineaPedido obj) {
        String sql = "UPDATE linea_pedido SET num_pedido = ?, cod_art = ? WHERE num_pedido = ";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, obj.getNum_pedido());
            stmt.setInt(2, obj.getArticulo().getCodigoArticulo());
            stmt.setInt(3, obj.getNum_pedido());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para eliminar una línea de pedido de la base de datos.
     *
     * @param numPedido Número de pedido de la línea de pedido a eliminar.
     * */
    @Override
    public void eliminar(Integer numPedido) {
        String sql = "DELETE FROM linea_pedido WHERE num_pedido = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numPedido);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo para obtener una línea de pedido por su ID.
     *
     * @param id ID de la línea de pedido a obtener.
     * @return Objeto LineaPedido correspondiente al ID proporcionado, o null si no se encuentra.
     * */
    @Override
    public LineaPedido obtenerPorId(Integer id) {
        String sql = "SELECT * FROM LineaPedido WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return construirDesdeResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
    }
        return null;
    }

    /**
     * Metodo para obtener todas las líneas de pedido de la base de datos.
     *
     * @return Lista de objetos LineaPedido que representan todas las líneas de pedido en la base de datos.
     * */
    @Override
    public List<LineaPedido> obtenerTodos() {
        // Lista para almacenar todas las líneas de pedido
        List<LineaPedido> lineasPedido = new ArrayList<>();
        String sql = "SELECT * FROM LineaPedido";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                LineaPedido linea = construirDesdeResultSet(rs);
                lineasPedido.add(linea);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lineasPedido;
    }

    /**
     * Metodo para obtener todas las líneas de pedido asociadas a un número de pedido específico.
     *
     * @param numeroPedido Número de pedido del cual se desean obtener las líneas de pedido.
     * @return Lista de objetos LineaPedido que representan las líneas de pedido asociadas al número de pedido proporcionado.
     * */
    public List<LineaPedido> obtenerLineaPorPedido(int numeroPedido) {
        List<LineaPedido> lineasPedido = new ArrayList<>();
        String sql = "SELECT * FROM linea_pedido WHERE num_pedido = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numeroPedido);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lineasPedido.add(construirDesdeResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lineasPedido;
    }


    /**
     * Metodo para construir un objeto LineaPedido a partir de un ResultSet.
     *
     * @param rs ResultSet que contiene los datos de la línea de pedido.
     * @return Objeto LineaPedido construido a partir del ResultSet proporcionado.
     * */
    @Override
    public LineaPedido construirDesdeResultSet(ResultSet rs) throws SQLException {

        ArticuloDAO artDao = new ArticuloDAO();

        int numPedido = rs.getInt("num_pedido");
        int articuloId = rs.getInt("cod_art");
        Articulo articulo = artDao.obtenerPorId(articuloId);
        return new LineaPedido(numPedido, articulo);
    }

    /**
     * Metodo para obtener todos los artículos asociados a un número de pedido específico.
     *
     * @param numeroPedido Número de pedido del cual se desean obtener los artículos.
     * @return Lista de objetos Articulo que representan los artículos asociados al número de pedido proporcionado.
     * */
    public List<Articulo> obtenerArticulosPorPedido(int numeroPedido) {
        List<Articulo> lista = new ArrayList<>();
        String sql ="SELECT articulo.* \n" +
                "FROM linea_pedido \n" +
                "JOIN articulo ON linea_pedido.cod_art = articulo.cod_art \n" +
                "WHERE linea_pedido.num_pedido = ?;\n";


        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numeroPedido);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Articulo articulo = new Articulo(
                        rs.getInt("cod_art"),
                        rs.getString("nombre"),
                        rs.getDouble("precio"),
                        rs.getString("descripcion")
                );
                lista.add(articulo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * Metodo para eliminar un artículo de un pedido específico.
     *
     * @param numeroPedido Número de pedido del cual se desea eliminar el artículo.
     * @param codArticulo Código del artículo a eliminar.
     * */
    public void eliminarArticuloDePedido(int numeroPedido, int codArticulo) {
        String sql = "DELETE FROM linea_pedido WHERE num_pedido = ? AND cod_art = ? LIMIT 1";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numeroPedido);
            stmt.setInt(2, codArticulo);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
