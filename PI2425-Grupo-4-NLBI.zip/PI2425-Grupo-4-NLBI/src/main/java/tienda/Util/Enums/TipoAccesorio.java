package tienda.Util.Enums;

public enum TipoAccesorio{
    bolso("bolso"),  zapato("zapato");

    private final String descripcion;
    TipoAccesorio(String descripcion){
        this.descripcion = descripcion;
    }

}
