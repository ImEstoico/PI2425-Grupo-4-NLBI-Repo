/**
 * Clase MenúPlantillaBD que gestiona las operaciones relacionadas con
 * los usuarios y pedidos en la base de datos a través de un menú interactivo.
 */
package tienda.Util.Console;

import tienda.Model.Pedidos.Metodo_Pago;
import tienda.Model.Articulos.Articulo;
import tienda.Model.Clientes.Cliente;
import tienda.Model.Empleados.Empleado;
import tienda.Model.Pedidos.Pedido;
import tienda.Model.Usuarios.Usuario;
import tienda.dao.ClienteDAO;
import tienda.dao.DBUtil;
import tienda.dao.GenericDAO;
import tienda.dao.PedidoDAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MenúPlantillaBD {

    private GenericDAO<Usuario, String> usuarioDAO; // DAO para operaciones de Usuario
    private GenericDAO<Empleado, String> empleadoDAO; // DAO para operaciones de Empleado
    private GenericDAO<Articulo, String> articuloDAO; // DAO para operaciones de Artículo

    /**
     * Constructor de la clase MenúPlantillaBD.
     *
     * @param usuarioDAO DAO para operaciones de Usuario.
     * @param empleadoDAO DAO para operaciones de Empleado.
     * @param articuloDAO DAO para operaciones de Artículo.
     * @throws SQLException Si ocurre un error de conexión a la base de datos.
     */
    public MenúPlantillaBD(GenericDAO<Usuario, String> usuarioDAO, GenericDAO<Empleado, String> empleadoDAO,
                           GenericDAO<Articulo, String> articuloDAO) throws SQLException {
        this.usuarioDAO = usuarioDAO;
        this.empleadoDAO = empleadoDAO;
        this.articuloDAO = articuloDAO;
    }

    Connection conexion = DBUtil.getConnection(); // Conexión a la base de datos

    /**
     * Muestra el menú principal para la gestión de usuarios y pedidos.
     */
    public void mostrarMenuClientela() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Menú Clientela:");
            System.out.println("1. Listar usuario por DNI");
            System.out.println("2. Añadir usuario");
            System.out.println("3. Cargar Clientes desde BD");
            System.out.println("4. Modificar usuario");
            System.out.println("5. Validar contraseña");
            System.out.println("6. Añadir Pedido");
            System.out.println("7. Listar Pedidos cliente");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    listarUsuarioPorDNI(scanner);
                    break;
                case 2:
                    añadirUsuario(scanner);
                    break;
                case 3:
                    cargarClientesDesdeBD(scanner);
                    break;
                case 4:
                    modificarUsuario(scanner);
                    break;
                case 5:
                    validarContraseña(scanner);
                    break;
                case 6:
                    añadirPedido(scanner);
                    break;
                case 7:
                    listarPedidosCliente(scanner);
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    // Métodos para las operaciones

    /**
     * Lista un usuario por su DNI.
     *
     * @param scanner Scanner para la entrada del usuario.
     */
    private void listarUsuarioPorDNI(Scanner scanner) {
        System.out.print("Introduzca el DNI: ");
        String dni = scanner.next();
        Usuario usuario = usuarioDAO.obtenerPorId(dni);
        System.out.println(usuario);
    }

    /**
     * Añade un nuevo usuario a la base de datos.
     *
     * @param scanner Scanner para la entrada del usuario.
     */
    private void añadirUsuario(Scanner scanner) {
        System.out.print("Introduzca el DNI: ");
        String dni = scanner.next();
        System.out.print("Introduzca apellidos: ");
        String apellidos = scanner.next();
        System.out.print("Introduzca nombre: ");
        String nombre = scanner.next();
        System.out.print("Introduzca el Telefono: ");
        int telefono = scanner.nextInt();
        System.out.print("Introduzca la dirección: ");
        String direccion = scanner.next();
        System.out.print("Introduzca el email: ");
        String email = scanner.next();
        boolean activo = true;
        System.out.print("Introduzca la contraseña: ");
        String pass = scanner.next();
        System.out.print("Introduzca la fecha de nacimiento (YYYY-MM-DD): ");
        LocalDate fechaNacimiento = LocalDate.parse(scanner.next());
        int numeroPedidos = 0;
        boolean tieneTarjetaFidelizacion = false;
        System.out.print("Introduzca direccion de envio: ");
        String direccionEnvio = scanner.next();
        Metodo_Pago metodoPago = null;
        ArrayList<Pedido> pedidos = new ArrayList<>();

        ClienteDAO clienteDAO = new ClienteDAO();
        Cliente cliente = new Cliente(dni, apellidos, nombre, telefono, direccion, email, activo, pass,
                fechaNacimiento, numeroPedidos, tieneTarjetaFidelizacion, direccionEnvio, metodoPago, pedidos);

        clienteDAO.insertar(cliente);
    }

    /**
     * Carga clientes desde la base de datos.
     *
     * @param scanner Scanner para la entrada del usuario.
     */
    private void cargarClientesDesdeBD(Scanner scanner) {
        ClienteDAO clienteDAO = new ClienteDAO();
        System.out.print("Introduzca el DNI: ");
        String dni = scanner.next();

        List<Usuario> usuarios = usuarioDAO.obtenerTodos();
        clienteDAO.obtenerPorId(dni);
        for (Usuario usuario : usuarios) {
            System.out.println(usuario);
        }
    }

    /**
     * Modifica un usuario existente en la base de datos.
     *
     * @param scanner Scanner para la entrada del usuario.
     */
    private void modificarUsuario(Scanner scanner) {
        ClienteDAO clienteDAO = new ClienteDAO();

        System.out.print("Introduzca el DNI del cliente para actualizar: ");
        String dni = scanner.next();
        Cliente aux = clienteDAO.obtenerPorId(dni);

        System.out.println("¿Quieres desactivar la cuenta? (true/false)");
        boolean activo = scanner.nextBoolean();

        if (activo) {
            aux.setActivo(false);
            System.out.println("Cuenta desactivada");
            clienteDAO.actualizar(aux);
        } else {
            aux.setActivo(true);
            System.out.println("Introduzca sus nuevos datos:");

            System.out.print("Introduzca apellidos: ");
            String apellidos = scanner.next();
            apellidos = (apellidos.isEmpty()) ? aux.getApellidos() : apellidos;

            System.out.print("Introduzca nombre: ");
            String nombre = scanner.next();
            nombre = (nombre.isEmpty()) ? aux.getNombre() : nombre;

            System.out.print("Introduzca el Telefono: ");
            int telefono = scanner.nextInt();
            telefono = (telefono == 0) ? aux.getTelefono() : telefono;

            System.out.print("Introduzca la dirección: ");
            String direccion = scanner.next();
            direccion = (direccion.isEmpty()) ? aux.getDireccion() : direccion;

            System.out.print("Introduzca el email: ");
            String email = scanner.next();
            email = (email.isEmpty()) ? aux.getEmail() : email;

            System.out.print("Introduzca la contraseña: ");
            String pass = scanner.next();

            System.out.print("Introduzca la fecha de nacimiento (YYYY-MM-DD): ");
            LocalDate fechaNacimiento = LocalDate.parse(scanner.next());
            int numeroPedidos = 0;
            boolean tieneTarjetaFidelizacion = false;

            System.out.print("Introduzca direccion de envio: ");
            String direccionEnvio = scanner.next();
            Metodo_Pago metodoPago = null;
            ArrayList<Pedido> pedidos = new ArrayList<>();

            Cliente cliente = new Cliente(dni, apellidos, nombre, telefono, direccion, email, activo, pass,
                    fechaNacimiento, numeroPedidos, tieneTarjetaFidelizacion, direccionEnvio, metodoPago, pedidos);

            clienteDAO.actualizar(cliente);
        }
    }

    /**
     * Valida la contraseña de un usuario (implementación pendiente).
     *
     * @param scanner Scanner para la entrada del usuario.
     */
    private void validarContraseña(Scanner scanner) {
        // Implementar lógica para validar contraseña
    }

    /**
     * Añade un nuevo pedido a la base de datos.
     *
     * @param scanner Scanner para la entrada del usuario.
     */
    private void añadirPedido(Scanner scanner) {
        PedidoDAO pedidoDAO = new PedidoDAO();

        System.out.println("Introduzca el número de pedido: ");
        int numeroP = scanner.nextInt();
        System.out.println("Introduzca la fecha del pedido: ");
        Date fechap = new Date(Date.parse(scanner.next()));
        System.out.println("Introduzca la dirección de envío: ");
        String direccionP = scanner.next();
        System.out.println("Introduzca el estado del pedido: ");
        String estadoP = scanner.next();
        System.out.println("Introduzca el método de pago: 1. efectivo, 2. tarjeta, 3. paypal, 4. bizum");
        int idMetodoP = scanner.nextInt();
        Metodo_Pago metodoP = new Metodo_Pago(idMetodoP, null);
        System.out.println("Introduzca el DNI del cliente: ");
        String dniCliente = scanner.next();

        Pedido pedido = new Pedido(numeroP, fechap, direccionP, dniCliente, metodoP, null, null, estadoP);

        pedidoDAO.insertar(pedido);
    }

    /**
     * Lista todos los pedidos de un cliente.
     *
     * @param scanner Scanner para la entrada del usuario.
     */
    private void listarPedidosCliente(Scanner scanner) {
        PedidoDAO pedidoDAO = new PedidoDAO();
        pedidoDAO.obtenerTodos();
    }

    // Métodos para el menú Plantilla y Catálogo se implementarían de manera similar
}
