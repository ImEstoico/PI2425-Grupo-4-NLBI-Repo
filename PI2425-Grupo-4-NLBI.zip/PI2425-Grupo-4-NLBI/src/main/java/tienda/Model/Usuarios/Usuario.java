/**
 * Clase abstracta Usuario que representa un usuario en el sistema,
 * incluyendo información personal como DNI, nombre, apellidos,
 * teléfono, dirección, correo electrónico, estado activo, contraseña
 * y fecha de nacimiento.
 */
package tienda.Model.Usuarios;

import java.time.LocalDate;

public abstract class Usuario {

    private String dni; // Documento Nacional de Identidad del usuario
    private String nombre; // Nombre del usuario
    private String apellidos; // Apellidos del usuario
    private int telefono; // Número de teléfono del usuario
    private String direccion; // Dirección del usuario
    private String email; // Correo electrónico del usuario
    private boolean activo; // Estado de actividad del usuario
    private String pass; // Contraseña del usuario
    private LocalDate f_nacimiento; // Fecha de nacimiento del usuario

    /**
     * Constructor de la clase Usuario.
     *
     * @param dni Documento Nacional de Identidad del usuario.
     * @param apellidos Apellidos del usuario.
     * @param nombre Nombre del usuario.
     * @param telefono Número de teléfono del usuario.
     * @param direccion Dirección del usuario.
     * @param email Correo electrónico del usuario.
     * @param activo Estado de actividad del usuario.
     * @param pass Contraseña del usuario.
     * @param f_nacimiento Fecha de nacimiento del usuario.
     */
    public Usuario(String dni, String apellidos, String nombre, int telefono,
                   String direccion, String email, boolean activo, String pass, LocalDate f_nacimiento) {
        this.dni = dni;
        this.apellidos = apellidos;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.email = email;
        this.activo = activo;
        this.pass = pass;
        this.f_nacimiento = f_nacimiento;
    }

    // Getters

    /**
     * Obtiene el DNI del usuario.
     *
     * @return El DNI del usuario.
     */
    public String getDni() {
        return this.dni;
    }

    /**
     * Obtiene el nombre del usuario.
     *
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Verifica si el usuario está activo.
     *
     * @return true si el usuario está activo, false en caso contrario.
     */
    public boolean isActivo() {
        return this.activo;
    }

    /**
     * Obtiene la contraseña del usuario.
     *
     * @return La contraseña del usuario.
     */
    public String getPass() {
        return this.pass;
    }

    /**
     * Obtiene los apellidos del usuario.
     *
     * @return Los apellidos del usuario.
     */
    public String getApellidos() {
        return this.apellidos;
    }

    /**
     * Obtiene el número de teléfono del usuario.
     *
     * @return El número de teléfono del usuario.
     */
    public int getTelefono() {
        return this.telefono;
    }

    /**
     * Obtiene la dirección del usuario.
     *
     * @return La dirección del usuario.
     */
    public String getDireccion() {
        return this.direccion;
    }

    /**
     * Obtiene el correo electrónico del usuario.
     *
     * @return El correo electrónico del usuario.
     */
    public String getEmail() {
        return this.email;
    }

    /**
     * Obtiene la fecha de nacimiento del usuario en formato de cadena.
     *
     * @return La fecha de nacimiento del usuario.
     */
    public String getFechaNacimiento() {
        return this.f_nacimiento.toString();
    }

    // Setters

    /**
     * Establece un nuevo DNI para el usuario.
     *
     * @param dni El nuevo DNI a establecer.
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * Establece un nuevo nombre para el usuario.
     *
     * @param nombre El nuevo nombre a establecer.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Establece nuevos apellidos para el usuario.
     *
     * @param apellidos Los nuevos apellidos a establecer.
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * Establece un nuevo número de teléfono para el usuario.
     *
     * @param telefono El nuevo número de teléfono a establecer.
     */
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    /**
     * Establece una nueva dirección para el usuario.
     *
     * @param direccion La nueva dirección a establecer.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Establece un nuevo correo electrónico para el usuario.
     *
     * @param email El nuevo correo electrónico a establecer.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Establece el estado de actividad del usuario.
     *
     * @param activo El nuevo estado de actividad a establecer.
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    /**
     * Establece una nueva contraseña para el usuario.
     *
     * @param pass La nueva contraseña a establecer.
     */
    public void setPass(String pass) {
        this.pass = pass;
    }

    /**
     * Obtiene la fecha de nacimiento del usuario.
     *
     * @return La fecha de nacimiento del usuario.
     */
    public LocalDate getF_nacimiento() {
        return f_nacimiento;
    }

    /**
     * Establece una nueva fecha de nacimiento para el usuario.
     *
     * @param f_nacimiento La nueva fecha de nacimiento a establecer.
     */
    public void setF_nacimiento(LocalDate f_nacimiento) {
        this.f_nacimiento = f_nacimiento;
    }

    /**
     * Devuelve una representación en cadena del usuario.
     *
     * @return Representación en cadena del usuario.
     */
    @Override
    public String toString() {
        return "Usuario{" +
                "dni='" + dni + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", telefono=" + telefono +
                ", direccion='" + direccion + '\'' +
                ", email='" + email + '\'' +
                ", activo=" + activo +
                ", pass='" + pass + '\'' +
                '}';
    }
}
