/**
 * Clase LineaPedido que representa una línea en un pedido,
 * asociando un artículo a un número de pedido específico.
 */
package tienda.Model.Pedidos;

import tienda.Model.Articulos.Articulo;

public class LineaPedido {

    private int num_pedido; // Número del pedido
    private Articulo articulo; // Artículo asociado a la línea del pedido

    /**
     * Constructor de la clase LineaPedido.
     *
     * @param num_pedido Número del pedido al que pertenece esta línea.
     * @param articulo Artículo que se incluye en la línea del pedido.
     */
    public LineaPedido(int num_pedido, Articulo articulo) {
        this.num_pedido = num_pedido;
        this.articulo = articulo;
    }

    /**
     * Obtiene el artículo de la línea de pedido.
     *
     * @return El artículo asociado a esta línea de pedido.
     */
    public Articulo getArticulo() {
        return this.articulo;
    }

    /**
     * Establece un nuevo artículo para la línea de pedido.
     *
     * @param articulo El nuevo artículo a establecer.
     */
    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    /**
     * Obtiene el número de pedido asociado a esta línea.
     *
     * @return El número de pedido.
     */
    public int getNum_pedido() {
        return this.num_pedido;
    }

    /**
     * Establece un nuevo número de pedido para esta línea.
     *
     * @param num_pedido El nuevo número de pedido a establecer.
     */
    public void setNum_pedido(int num_pedido) {
        this.num_pedido = num_pedido;
    }

    /**
     * Devuelve una representación en cadena de la línea de pedido.
     *
     * @return Representación en cadena de la línea de pedido.
     */
    @Override
    public String toString() {
        return "LineaPedido{" +
                "num_pedido=" + num_pedido +
                ", articulo=" + articulo +
                '}';
    }
}
