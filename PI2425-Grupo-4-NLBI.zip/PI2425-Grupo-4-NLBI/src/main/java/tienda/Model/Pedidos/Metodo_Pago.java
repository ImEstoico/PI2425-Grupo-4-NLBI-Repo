/**
 * Clase Metodo_Pago que representa un método de pago,
 * incluyendo su código, descripción y una lista de pedidos asociados.
 */
package tienda.Model.Pedidos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class Metodo_Pago {

    private int codigo; // Código del método de pago
    private String descripcion; // Descripción del método de pago
    private ArrayList<Pedido> pedidos; // Lista de pedidos asociados a este método de pago

    /**
     * Constructor de la clase Metodo_Pago.
     *
     * @param codigo Código del método de pago.
     * @param descripcion Descripción del método de pago.
     */
    @JsonCreator
    public Metodo_Pago(
            @JsonProperty("codigo") int codigo,
            @JsonProperty("descripcion") String descripcion) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.pedidos = new ArrayList<>(); // Inicializa la lista de pedidos como vacía
    }

    /**
     * Constructor de la clase Metodo_Pago con pedidos asociados.
     *
     * @param codigo Código del método de pago.
     * @param descripcion Descripción del método de pago.
     * @param pedidos Lista de pedidos asociados a este método de pago.
     */
    @JsonCreator
    public Metodo_Pago(
            @JsonProperty("codigo") int codigo,
            @JsonProperty("descripcion") String descripcion,
            ArrayList<Pedido> pedidos) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.pedidos = pedidos;
    }

    // Getters

    /**
     * Obtiene el código del método de pago.
     *
     * @return El código del método de pago.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Obtiene la descripción del método de pago.
     *
     * @return La descripción del método de pago.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Obtiene la lista de pedidos asociados a este método de pago.
     *
     * @return Lista de pedidos.
     */
    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    // Setters

    /**
     * Establece un nuevo código para el método de pago.
     *
     * @param codigo El nuevo código a establecer.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Establece una nueva descripción para el método de pago.
     *
     * @param descripcion La nueva descripción a establecer.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Establece una nueva lista de pedidos asociados a este método de pago.
     *
     * @param pedidos La nueva lista de pedidos a establecer.
     */
    public void setPedidos(ArrayList<Pedido> pedidos) {
        this.pedidos = pedidos;
    }
}
