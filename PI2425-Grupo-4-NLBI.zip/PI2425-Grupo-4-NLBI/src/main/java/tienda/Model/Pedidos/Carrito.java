/**
 * Clase Carrito que representa un carrito de compras que almacena artículos seleccionados por el usuario.
 */
package tienda.Model.Pedidos;

import tienda.SceneBuilder.HelloApplication;
import tienda.Model.Articulos.Articulo;
import tienda.dao.LineaPedidoDAO;
import tienda.dao.PedidoDAO;

import java.util.ArrayList;
import java.util.List;

public class Carrito {
    private List<Articulo> articulos; // Lista de artículos en el carrito

    /**
     * Constructor de la clase Carrito que inicializa la lista de artículos
     * y carga los artículos desde un pedido actual.
     */
    public Carrito() {
        this.articulos = new ArrayList<>();
        cargarArticulosDesdePedido();
    }

    /**
     * Carga los artículos desde el pedido actual del usuario.
     * Si no hay un pedido actual, inicializa la lista de artículos como vacía.
     */
    private void cargarArticulosDesdePedido() {
        PedidoDAO pedidoDAO = new PedidoDAO();
        String dni = HelloApplication.getUser().getDni();
        Pedido pedido = pedidoDAO.obtenerPedidoActualPorUsuario(dni);

        if (pedido != null) {
            LineaPedidoDAO lineaDAO = new LineaPedidoDAO();
            this.articulos = lineaDAO.obtenerArticulosPorPedido(pedido.getNumeroPedido());
        } else {
            this.articulos = new ArrayList<>();
        }
    }

    /**
     * Obtiene la lista de artículos en el carrito.
     *
     * @return Lista de artículos.
     */
    public List<Articulo> getArticulos() {
        return articulos;
    }

    /**
     * Elimina un artículo del carrito por su índice.
     * También elimina el artículo del pedido actual en la base de datos.
     *
     * @param index Índice del artículo a eliminar.
     */
    public void eliminarArticuloPorIndice(int index) {
        PedidoDAO pedidoDAO = new PedidoDAO();
        String dni = HelloApplication.getUser().getDni();
        Pedido pedido = pedidoDAO.obtenerPedidoActualPorUsuario(dni);

        if (pedido != null && index < articulos.size()) {
            Articulo articulo = articulos.get(index);
            LineaPedidoDAO lineaDAO = new LineaPedidoDAO();
            lineaDAO.eliminarArticuloDePedido(pedido.getNumeroPedido(), articulo.getCodigoArticulo());
            articulos.remove(index);
        }
    }

    /**
     * Calcula el total de los artículos en el carrito.
     *
     * @return El total acumulado de los precios de los artículos.
     */
    public double calcularTotal() {
        return articulos.stream().mapToDouble(Articulo::getPrecio).sum();
    }
}
