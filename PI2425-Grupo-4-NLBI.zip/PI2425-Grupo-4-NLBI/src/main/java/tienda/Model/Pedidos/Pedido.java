/**
 * Clase Pedido que representa un pedido realizado por un cliente,
 * incluyendo detalles como el número de pedido, fecha, dirección de envío,
 * estado del pedido, DNI del cliente, método de pago y líneas de pedido.
 */
package tienda.Model.Pedidos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import tienda.Model.Clientes.Cliente;
import tienda.Util.Enums.EstadoPedido;

import java.util.ArrayList;
import java.util.Date;

public class Pedido {

    private int numeroPedido; // Número del pedido
    private Date fecha; // Fecha de creación del pedido
    private String dir_envio; // Dirección de envío del pedido
    private EstadoPedido estadoPedido; // Estado actual del pedido
    private String DNI_cliente; // DNI del cliente que realiza el pedido
    private Metodo_Pago metodoPago; // Método de pago utilizado
    private ArrayList<LineaPedido> lineaPedidos; // Lista de líneas de pedido
    private ArrayList<Cliente> clientes; // Lista de clientes asociados

    /**
     * Constructor de la clase Pedido.
     *
     * @param numeroPedido Número del pedido.
     * @param fecha Fecha de creación del pedido.
     * @param dir_envio Dirección de envío del pedido.
     * @param DNI_cliente DNI del cliente que realiza el pedido.
     * @param metodoPago Método de pago utilizado.
     * @param lineaPedidos Lista de líneas de pedido.
     * @param clientes Lista de clientes asociados.
     * @param estadoPedido Estado del pedido (se inicializa como EN_PROCESO).
     */
    @JsonCreator
    public Pedido(
            @JsonProperty("numeroPedido") int numeroPedido,
            @JsonProperty("fecha") Date fecha,
            @JsonProperty("dir_envio") String dir_envio,
            @JsonProperty("DNI_cliente") String DNI_cliente,
            Metodo_Pago metodoPago,
            ArrayList<LineaPedido> lineaPedidos,
            ArrayList<Cliente> clientes,
            @JsonProperty("estado") String estadoPedido) {
        this.numeroPedido = numeroPedido;
        this.fecha = fecha;
        this.dir_envio = dir_envio;
        this.estadoPedido = EstadoPedido.EN_PROCESO; // Inicializa el estado como EN_PROCESO
        this.DNI_cliente = DNI_cliente;
        this.metodoPago = metodoPago;
        this.lineaPedidos = lineaPedidos;
        this.clientes = clientes;
    }

    // Getters

    /**
     * Obtiene el número del pedido.
     *
     * @return El número del pedido.
     */
    public int getNumeroPedido() {
        return numeroPedido;
    }

    /**
     * Obtiene la fecha de creación del pedido.
     *
     * @return La fecha del pedido.
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * Obtiene la dirección de envío del pedido.
     *
     * @return La dirección de envío.
     */
    public String getDir_envio() {
        return dir_envio;
    }

    /**
     * Obtiene el estado actual del pedido.
     *
     * @return El estado del pedido.
     */
    public EstadoPedido getEstadoPedido() {
        return this.estadoPedido;
    }

    /**
     * Establece un nuevo estado para el pedido.
     *
     * @param estadoPedido El nuevo estado a establecer.
     */
    public void setEstadoPedido(EstadoPedido estadoPedido) {
        this.estadoPedido = estadoPedido;
    }

    /**
     * Obtiene la lista de líneas de pedido.
     *
     * @return Lista de líneas de pedido.
     */
    public ArrayList<LineaPedido> getLineaPedidos() {
        return lineaPedidos;
    }

    /**
     * Obtiene la lista de clientes asociados al pedido.
     *
     * @return Lista de clientes.
     */
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    /**
     * Obtiene el DNI del cliente que realizó el pedido.
     *
     * @return El DNI del cliente.
     */
    public String getDNI_cliente() {
        return DNI_cliente;
    }

    /**
     * Obtiene el método de pago utilizado para el pedido.
     *
     * @return El método de pago.
     */
    public Metodo_Pago getMetodoPago() {
        return metodoPago;
    }

    // Setters

    /**
     * Establece un nuevo número para el pedido.
     *
     * @param numeroPedido El nuevo número a establecer.
     */
    public void setNumeroPedido(int numeroPedido) {
        this.numeroPedido = numeroPedido;
    }

    /**
     * Establece una nueva lista de líneas de pedido.
     *
     * @param lineaPedidos La nueva lista de líneas de pedido.
     */
    public void setLineaPedidos(ArrayList<LineaPedido> lineaPedidos) {
        this.lineaPedidos = lineaPedidos;
    }

    /**
     * Establece una nueva lista de clientes asociados al pedido.
     *
     * @param clientes La nueva lista de clientes.
     */
    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    /**
     * Establece una nueva fecha para el pedido.
     *
     * @param fecha La nueva fecha a establecer.
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    /**
     * Establece una nueva dirección de envío para el pedido.
     *
     * @param dir_envio La nueva dirección de envío.
     */
    public void setDir_envio(String dir_envio) {
        this.dir_envio = dir_envio;
    }

    /**
     * Muestra información del pedido en la consola.
     */
    public void mostrarPedido() {
        System.out.println("mostrar pedido");
    }

    /**
     * Calcula el total de los pedidos.
     */
    public void calcularTotal() {
        System.out.println("calcular total de pedidos");
    }

    /**
     * Establece un nuevo DNI para el cliente que realizó el pedido.
     *
     * @param DNI_cliente El nuevo DNI a establecer.
     */
    public void setDNI_cliente(String DNI_cliente) {
        this.DNI_cliente = DNI_cliente;
    }

    /**
     * Establece un nuevo método de pago para el pedido.
     *
     * @param metodoPago El nuevo método de pago a establecer.
     */
    public void setMetodoPago(Metodo_Pago metodoPago) {
        this.metodoPago = metodoPago;
    }

    /**
     * Devuelve una representación en cadena del pedido.
     *
     * @return Representación en cadena del pedido.
     */
    @Override
    public String toString() {
        return "Pedido{" +
                "numeroPedido=" + numeroPedido +
                ", fecha=" + fecha +
                ", dir_envio='" + dir_envio + '\'' +
                ", DNI_cliente='" + DNI_cliente + '\'' +
                ", lineaPedidos=" + lineaPedidos +
                ", clientes=" + clientes +
                '}';
    }
}
