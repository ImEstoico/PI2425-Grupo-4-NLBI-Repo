/**
 * Clase Catalogo que representa un catálogo de artículos en el sistema.
 * Permite gestionar una lista de artículos, incluyendo operaciones de búsqueda, filtrado y modificación.
 */
package tienda.Model.Catalogo;

import tienda.Model.Articulos.Articulo;

import java.util.ArrayList;
import java.util.Iterator;

public class Catalogo {
    private ArrayList<Articulo> articulos; // Lista de artículos en el catálogo

    /**
     * Obtiene la lista de artículos en el catálogo.
     *
     * @return ArrayList de artículos.
     */
    public ArrayList<Articulo> getArticulo() {
        return articulos;
    }

    /**
     * Establece la lista de artículos en el catálogo.
     *
     * @param articulos La nueva lista de artículos.
     */
    public void setArticulo(ArrayList<Articulo> articulos) {
        this.articulos = articulos;
    }

    /**
     * Filtra un artículo por su código.
     *
     * @param cod El código del artículo a buscar.
     * @return El artículo encontrado o null si no existe.
     */
    public Articulo filtrarPorCodigo(int cod) {
        for (Articulo art : articulos) {
            if (art.getCodigoArticulo() == cod) {
                return art;
            }
        }
        return null;
    }

    /**
     * Añade un nuevo artículo al catálogo.
     *
     * @param nuevo El nuevo artículo a añadir.
     * @return true si se añadió correctamente, false si ya existe.
     */
    public boolean addArticulo(Articulo nuevo) {
        Articulo existente = filtrarPorCodigo(nuevo.getCodigoArticulo());
        if (existente == null) {
            articulos.add(nuevo);
            return true;
        } else {
            System.out.println("Artículo duplicado");
            return false;
        }
    }

    /**
     * Actualiza un artículo existente en el catálogo.
     *
     * @param nuevo El artículo con los nuevos datos.
     * @return true si se actualizó correctamente, false si no se encontró.
     */
    public boolean updateArticulo(Articulo nuevo) {
        Articulo existente = filtrarPorCodigo(nuevo.getCodigoArticulo());
        if (existente != null) {
            existente.setNombre(nuevo.getNombre());
            existente.setPrecio(nuevo.getPrecio());
            existente.setMarca(nuevo.getMarca());
            existente.setDescripcion(nuevo.getDescripcion());
            existente.setImagen(nuevo.getImagen());
            existente.setActivo(nuevo.isActivo());
            existente.setColor(nuevo.getColor());
            existente.setMaterial(nuevo.getMaterial());
            return true;
        }
        System.out.println("Artículo no encontrado");
        return false;
    }

    /**
     * Elimina un artículo del catálogo por su código.
     *
     * @param id El código del artículo a eliminar.
     * @return true si se eliminó correctamente, false si no se encontró.
     */
    public boolean deleteArticulo(int id) {
        Iterator<Articulo> iterador = articulos.iterator();
        while (iterador.hasNext()) {
            Articulo art = iterador.next();
            if (art.getCodigoArticulo() == id) {
                iterador.remove();
                return true;
            }
        }
        System.out.println("Artículo no encontrado");
        return false;
    }

    /**
     * Busca artículos activos.
     *
     * @param activo El estado de activación a buscar.
     * @return Una lista de artículos que coinciden con el estado de activación.
     */
    public ArrayList<Articulo> buscarPorActivo(boolean activo) {
        ArrayList<Articulo> sublista = new ArrayList<>();
        for (Articulo art : articulos) {
            if (art.isActivo() == activo) {
                sublista.add(art);
            }
        }
        return sublista;
    }

    // Puedes añadir más métodos de filtrado o búsqueda según sea necesario.
}
