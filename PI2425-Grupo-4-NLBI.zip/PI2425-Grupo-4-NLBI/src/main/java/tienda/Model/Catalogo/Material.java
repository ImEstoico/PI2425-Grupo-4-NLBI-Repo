/**
 * Clase Material que representa un tipo de material utilizado en los artículos.
 */
package tienda.Model.Catalogo;

public class Material {

    private int codigo;          // Código del material
    private String denominacion; // Denominación del material

    /**
     * Constructor de la clase Material.
     *
     * @param codigo El código del material.
     * @param denominacion La denominación del material.
     */
    public Material(int codigo, String denominacion) {
        this.codigo = codigo;
        this.denominacion = denominacion;
    }

    /**
     * Obtiene el código del material.
     *
     * @return El código del material.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Establece el código del material.
     *
     * @param codigo El nuevo código del material.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtiene la denominación del material.
     *
     * @return La denominación del material.
     */
    public String getDenominacion() {
        return denominacion;
    }

    /**
     * Establece la denominación del material.
     *
     * @param denominacion La nueva denominación del material.
     */
    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }
}
