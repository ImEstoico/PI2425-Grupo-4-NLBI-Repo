/**
 * Clase Empleado que representa a un empleado en la organización.
 * Extiende la clase Usuario e implementa Serializable.
 */
package tienda.Model.Empleados;

import tienda.Model.Usuarios.Usuario;

import java.io.Serializable;
import java.time.LocalDate;

public class Empleado extends Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    private boolean tienePrivilegios; // Indica si el empleado tiene privilegios especiales
    private Departamento departamento; // Departamento al que pertenece el empleado

    /**
     * Constructor de la clase Empleado.
     *
     * @param dni DNI del empleado.
     * @param apellidos Apellidos del empleado.
     * @param nombre Nombre del empleado.
     * @param telefono Teléfono del empleado.
     * @param direccion Dirección del empleado.
     * @param email Correo electrónico del empleado.
     * @param activo Estado de actividad del empleado.
     * @param pass Contraseña del empleado.
     * @param f_nacimiento Fecha de nacimiento del empleado.
     * @param tienePrivilegios Indica si el empleado tiene privilegios especiales.
     * @param departamento Departamento al que pertenece el empleado.
     */
    public Empleado(String dni, String apellidos, String nombre, int telefono, String direccion,
                    String email, boolean activo, String pass, LocalDate f_nacimiento,
                    boolean tienePrivilegios, Departamento departamento) {
        super(dni, apellidos, nombre, telefono, direccion, email, activo, pass, f_nacimiento);
        this.tienePrivilegios = tienePrivilegios;
        this.departamento = departamento;
    }

    /**
     * Verifica si el empleado tiene privilegios especiales.
     *
     * @return true si tiene privilegios, false en caso contrario.
     */
    public boolean tienePrivilegios() {
        return this.tienePrivilegios;
    }

    /**
     * Obtiene el departamento del empleado.
     *
     * @return El departamento al que pertenece el empleado.
     */
    public Departamento getDepartamento() {
        return departamento;
    }

    /**
     * Establece si el empleado tiene privilegios especiales.
     *
     * @param tienePrivilegios El nuevo estado de privilegios del empleado.
     */
    public void setTienePrivilegios(boolean tienePrivilegios) {
        this.tienePrivilegios = tienePrivilegios;
    }

    /**
     * Establece el departamento al que pertenece el empleado.
     *
     * @param departamento El nuevo departamento del empleado.
     */
    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    /**
     * Realiza el alta de un usuario.
     */
    public void altaUsuario() {
        System.out.println("Alta de usuario");
    }

    /**
     * Realiza la baja de un usuario.
     */
    public void bajaUsuario() {
        System.out.println("Baja de usuario");
    }

    /**
     * Modifica la información de un usuario.
     */
    public void modificarUsuario() {
        System.out.println("Modificación de usuario");
    }

    /**
     * Consulta la información de un usuario.
     */
    public void consultarUsuario() {
        System.out.println("Consulta de usuario");
    }

    /**
     * Gestiona productos según los privilegios del empleado.
     * Si tiene privilegios o pertenece al departamento "Almacén", puede gestionar productos.
     */
    public void gestionarProducto() {
        if (tienePrivilegios || departamento.getNombre().equals("Almacén")) {
            System.out.println("Gestión de producto");
        } else {
            System.out.println("No tiene privilegios para gestionar productos");
        }
    }
}
