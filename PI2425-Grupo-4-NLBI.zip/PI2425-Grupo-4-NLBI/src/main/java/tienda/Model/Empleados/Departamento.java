/**
 * Clase Departamento que representa un departamento dentro de la organización.
 */
package tienda.Model.Empleados;

public class Departamento {

    private int codigo; // Código del departamento
    private String nombre; // Nombre del departamento

    /**
     * Constructor de la clase Departamento.
     *
     * @param codigo El código del departamento.
     * @param nombre El nombre del departamento.
     */
    public Departamento(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    /**
     * Obtiene el código del departamento.
     *
     * @return El código del departamento.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Establece el código del departamento.
     *
     * @param codigo El nuevo código del departamento.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtiene el nombre del departamento.
     *
     * @return El nombre del departamento.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del departamento.
     *
     * @param nombre El nuevo nombre del departamento.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
