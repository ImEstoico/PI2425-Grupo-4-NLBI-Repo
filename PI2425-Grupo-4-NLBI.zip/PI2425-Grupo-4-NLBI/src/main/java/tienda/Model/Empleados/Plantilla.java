/**
 * Clase Plantilla que representa un conjunto de empleados en la organización.
 */
package tienda.Model.Empleados;

import java.util.ArrayList;

public class Plantilla {

    private ArrayList<Empleado> empleados; // Lista de empleados

    /**
     * Constructor de la clase Plantilla que inicializa la lista de empleados.
     *
     * @param empleados Lista de empleados a inicializar.
     */
    public Plantilla(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    /**
     * Constructor por defecto que inicializa la lista de empleados vacía.
     */
    public Plantilla() {
        empleados = new ArrayList<>();
    }

    /**
     * Obtiene la lista de empleados.
     *
     * @return Lista de empleados.
     */
    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    /**
     * Establece la lista de empleados.
     *
     * @param empleados Nueva lista de empleados.
     */
    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    /**
     * Añade un nuevo empleado a la plantilla si no existe.
     *
     * @param nuevoEmpleado El nuevo empleado a añadir.
     */
    public void addEmpleado(Empleado nuevoEmpleado) {
        Empleado empleado = getEmpleado(nuevoEmpleado.getDni());
        if (empleado == null) {
            empleados.add(nuevoEmpleado);
        } else {
            System.out.println("Empleado ya existe");
        }
    }

    /**
     * Obtiene un empleado por su DNI.
     *
     * @param dni DNI del empleado a buscar.
     * @return El empleado encontrado o null si no existe.
     */
    public Empleado getEmpleado(String dni) {
        for (Empleado empleado : empleados) {
            if (empleado.getDni().equals(dni)) {
                return empleado;
            }
        }
        return null;
    }

    /**
     * Actualiza la información de un empleado existente.
     *
     * @param nuevoempleado El empleado con la nueva información.
     * @return true si se actualizó correctamente, false si no se encontró.
     */
    public boolean updateEmpleado(Empleado nuevoempleado) {
        for (Empleado empleado : empleados) {
            if (empleado.getDni().equals(nuevoempleado.getDni())) {
                empleado.setDni(nuevoempleado.getDni());
                empleado.setApellidos(nuevoempleado.getApellidos());
                empleado.setNombre(nuevoempleado.getNombre());
                empleado.setTelefono(nuevoempleado.getTelefono());
                empleado.setDireccion(nuevoempleado.getDireccion());
                empleado.setEmail(nuevoempleado.getEmail());
                empleado.setActivo(nuevoempleado.isActivo());
                empleado.setPass(nuevoempleado.getPass());
                empleado.setF_nacimiento(nuevoempleado.getF_nacimiento());
                empleado.setTienePrivilegios(nuevoempleado.tienePrivilegios());
                empleado.setDepartamento(nuevoempleado.getDepartamento());
                return true;
            }
        }
        System.out.println("Empleado no encontrado");
        return false;
    }

    /**
     * Elimina un empleado por su DNI.
     *
     * @param dni DNI del empleado a eliminar.
     * @return true si se eliminó correctamente, false si no se encontró.
     */
    public boolean deleteEmpleado(String dni) {
        for (Empleado empleado : empleados) {
            if (empleado.getDni().equals(dni)) {
                empleados.remove(empleado);
                return true;
            }
        }
        System.out.println("Empleado no encontrado");
        return false;
    }

    /**
     * Busca un empleado por su DNI y lo imprime.
     *
     * @param dni DNI del empleado a buscar.
     */
    public void buscarDniEmpleado(String dni) {
        for (Empleado empleado : empleados) {
            if (empleado.getDni().equals(dni)) {
                System.out.println(empleado);
            }
        }
    }

    /**
     * Filtra empleados por nombre y apellidos.
     *
     * @param nombre Nombre a filtrar.
     * @param apellidos Apellidos a filtrar.
     */
    public void filtrarNombresEmpleado(String nombre, String apellidos) {
        ArrayList<Empleado> empleadosFiltrados = new ArrayList<>();
        for (Empleado empleado : empleados) {
            if (empleado.getNombre().equals(nombre) && empleado.getApellidos().equals(apellidos)) {
                empleadosFiltrados.add(empleado);
            }
        }
        // Aquí podrías añadir lógica para hacer algo con empleadosFiltrados
    }

    /**
     * Filtra empleados por departamento.
     *
     * @param departamento Nombre del departamento a filtrar.
     */
    public void filtrarDepartamentoEmpleado(String departamento) {
        ArrayList<Empleado> empleadosFiltrados = new ArrayList<>();
        for (Empleado empleado : empleados) {
            if (empleado.getDepartamento().getNombre().equals(departamento)) {
                empleadosFiltrados.add(empleado);
            }
        }
        // Aquí podrías añadir lógica para hacer algo con empleadosFiltrados
    }

    /**
     * Filtra empleados por privilegios.
     *
     * @param tienePrivilegios Estado de privilegios a filtrar.
     */
    public void filtrarPrivilegiosEmpleado(boolean tienePrivilegios) {
        ArrayList<Empleado> empleadosFiltrados = new ArrayList<>();
        for (Empleado empleado : empleados) {
            if (empleado.tienePrivilegios() == tienePrivilegios) {
                empleadosFiltrados.add(empleado);
            }
        }
        // Aquí podrías añadir lógica para hacer algo con empleadosFiltrados
    }

    /**
     * Devuelve una representación en cadena de la plantilla.
     *
     * @return Representación en cadena de la plantilla.
     */
    @Override
    public String toString() {
        return "Plantilla{" +
                "empleados=" + empleados +
                '}';
    }
}
