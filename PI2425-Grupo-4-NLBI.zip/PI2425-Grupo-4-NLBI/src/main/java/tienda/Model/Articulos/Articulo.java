/**
 * Clase Articulo que representa un artículo en el sistema.
 * Contiene información básica sobre el artículo, como su código, nombre, precio, etc.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;

public class Articulo {
    protected int codigoArticulo;   // Código del artículo
    protected String nombre;         // Nombre del artículo
    protected float precio;          // Precio del artículo
    protected String marca;          // Marca del artículo
    protected String descripcion;    // Descripción del artículo
    protected String imagen;         // URL de la imagen del artículo
    protected boolean activo;        // Indica si el artículo está activo
    protected String color;          // Color del artículo
    protected Material material;     // Material del artículo

    /**
     * Constructor de la clase Articulo.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre del artículo.
     * @param precio El precio del artículo.
     * @param marca La marca del artículo.
     * @param descripcion La descripción del artículo.
     * @param imagen La imagen del artículo.
     * @param activo Indica si el artículo está activo.
     * @param color El color del artículo.
     * @param material El material del artículo.
     */
    public Articulo(int codigoArticulo, String nombre, float precio, String marca, String descripcion, String imagen, boolean activo, String color, Material material) {
        this.codigoArticulo = codigoArticulo;
        this.nombre = nombre;
        this.precio = precio;
        this.marca = marca;
        this.descripcion = descripcion;
        this.imagen = imagen;
        this.activo = activo;
        this.color = color;
        this.material = material;
    }

    /**
     * Constructor vacío de la clase Articulo.
     */
    public Articulo() {
    }

    /**
     * Constructor alternativo de la clase Articulo.
     *
     * @param codigo El código del artículo.
     * @param nombre El nombre del artículo.
     * @param precio El precio del artículo.
     * @param descripcion La descripción del artículo.
     */
    public Articulo(int codigo, String nombre, double precio, String descripcion) {
        // Implementar según sea necesario
    }

    /**
     * Obtiene el código del artículo.
     *
     * @return El código del artículo.
     */
    public int getCodigoArticulo() {
        return this.codigoArticulo;
    }

    /**
     * Establece el código del artículo.
     *
     * @param codigoArticulo El nuevo código del artículo.
     */
    public void setCodigoArticulo(int codigoArticulo) {
        this.codigoArticulo = codigoArticulo;
    }

    /**
     * Obtiene el nombre del artículo.
     *
     * @return El nombre del artículo.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Establece el nombre del artículo.
     *
     * @param nombre El nuevo nombre del artículo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el precio del artículo.
     *
     * @return El precio del artículo.
     */
    public float getPrecio() {
        return this.precio;
    }

    /**
     * Establece el precio del artículo.
     *
     * @param precio El nuevo precio del artículo.
     */
    public void setPrecio(float precio) {
        this.precio = precio;
    }

    /**
     * Obtiene la marca del artículo.
     *
     * @return La marca del artículo.
     */
    public String getMarca() {
        return this.marca;
    }

    /**
     * Establece la marca del artículo.
     *
     * @param marca La nueva marca del artículo.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Obtiene la descripción del artículo.
     *
     * @return La descripción del artículo.
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * Establece la descripción del artículo.
     *
     * @param descripcion La nueva descripción del artículo.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene la imagen del artículo.
     *
     * @return La URL de la imagen del artículo.
     */
    public String getImagen() {
        return imagen;
    }

    /**
     * Establece la imagen del artículo.
     *
     * @param imagen La nueva URL de la imagen del artículo.
     */
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    /**
     * Verifica si el artículo está activo.
     *
     * @return true si el artículo está activo, false en caso contrario.
     */
    public boolean isActivo() {
        return this.activo;
    }

    /**
     * Establece si el artículo está activo.
     *
     * @param activo true si el artículo está activo, false en caso contrario.
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    /**
     * Obtiene el color del artículo.
     *
     * @return El color del artículo.
     */
    public String getColor() {
        return this.color;
    }

    /**
     * Establece el color del artículo.
     *
     * @param color El nuevo color del artículo.
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Obtiene el material del artículo.
     *
     * @return El material del artículo.
     */
    public Material getMaterial() {
        return this.material;
    }

    /**
     * Establece el material del artículo.
     *
     * @param material El nuevo material del artículo.
     */
    public void setMaterial(Material material) {
        this.material = material;
    }
}
