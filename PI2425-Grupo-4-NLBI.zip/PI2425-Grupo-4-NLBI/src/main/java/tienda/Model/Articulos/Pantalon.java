/**
 * Clase Pantalon que representa un tipo específico de ropa en el sistema.
 * Hereda de la clase Ropa.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;

public class Pantalon extends Ropa {
    private boolean tieneBolsillo;  // Indica si el pantalón tiene bolsillo
    private String tipoPantalon;     // Tipo de pantalón (ej. jeans, cargo, etc.)

    /**
     * Constructor de la clase Pantalon.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre del pantalón.
     * @param precio El precio del pantalón.
     * @param marca La marca del pantalón.
     * @param descripcion La descripción del pantalón.
     * @param imagen La imagen del pantalón.
     * @param activo Indica si el pantalón está activo.
     * @param color El color del pantalón.
     * @param material El material del pantalón.
     * @param talla La talla del pantalón.
     * @param tipoCierre El tipo de cierre del pantalón.
     * @param tieneBolsillo Indica si el pantalón tiene bolsillo.
     * @param tipoPantalon El tipo de pantalón.
     */
    public Pantalon(int codigoArticulo, String nombre, float precio, String marca, String descripcion, String imagen,
                    boolean activo, String color, Material material, int talla, String tipoCierre, boolean tieneBolsillo,
                    String tipoPantalon) {
        super(codigoArticulo, nombre, precio, marca, descripcion, imagen, activo, color, material, talla, tipoCierre);
        this.tieneBolsillo = tieneBolsillo;
        this.tipoPantalon = tipoPantalon;
    }

    /**
     * Verifica si el pantalón tiene bolsillo.
     *
     * @return true si el pantalón tiene bolsillo, false en caso contrario.
     */
    public boolean isTieneBolsillo() {
        return this.tieneBolsillo;
    }

    /**
     * Establece si el pantalón tiene bolsillo.
     *
     * @param tieneBolsillo true si el pantalón tiene bolsillo, false en caso contrario.
     */
    public void setTieneBolsillo(boolean tieneBolsillo) {
        this.tieneBolsillo = tieneBolsillo;
    }

    /**
     * Obtiene el tipo de pantalón.
     *
     * @return El tipo de pantalón.
     */
    public String getTipoPantalon() {
        return this.tipoPantalon;
    }

    /**
     * Establece el tipo de pantalón.
     *
     * @param tipoPantalon El nuevo tipo de pantalón.
     */
    public void setTipoPantalon(String tipoPantalon) {
        this.tipoPantalon = tipoPantalon;
    }

    /**
     * Muestra los detalles del pantalón.
     */
    public void mostrarDetalles() {
        System.out.println("Pantalón: " + nombre + ", Tipo: " + tipoPantalon + ", Tiene Bolsillo: " + (tieneBolsillo ? "Sí" : "No"));
    }
}
