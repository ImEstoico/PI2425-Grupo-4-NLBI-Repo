/**
 * Clase Zapato que representa un tipo específico de accesorio en el sistema.
 * Hereda de la clase Accesorio.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;
import tienda.Util.Enums.TipoAccesorio;

public class Zapato extends Accesorio {
    private int tallaZapato;          // Talla del zapato
    private String tipoSuela;         // Tipo de suela del zapato
    private TipoAccesorio tipo;       // Tipo de accesorio del zapato

    /**
     * Constructor de la clase Zapato.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre del zapato.
     * @param precio El precio del zapato.
     * @param marca La marca del zapato.
     * @param descripcion La descripción del zapato.
     * @param imagen La imagen del zapato.
     * @param activo Indica si el zapato está activo.
     * @param color El color del zapato.
     * @param material El material del zapato.
     * @param estilo El estilo del zapato.
     * @param esPersonalizado Indica si el zapato es personalizado.
     * @param tallaZapato La talla del zapato.
     * @param tipoSuela El tipo de suela del zapato.
     * @param tipo El tipo de accesorio.
     */
    public Zapato(int codigoArticulo, String nombre, float precio, String marca, String descripcion, String imagen,
                  boolean activo, String color, Material material, String estilo, boolean esPersonalizado,
                  int tallaZapato, String tipoSuela, TipoAccesorio tipo) {
        super(codigoArticulo, nombre, precio, marca, descripcion, imagen, activo, color, material, estilo, esPersonalizado);
        this.tallaZapato = tallaZapato;
        this.tipoSuela = tipoSuela;
        this.tipo = tipo;
    }

    /**
     * Obtiene la talla del zapato.
     *
     * @return La talla del zapato.
     */
    public int getTallaZapato() {
        return this.tallaZapato;
    }

    /**
     * Establece la talla del zapato.
     *
     * @param tallaZapato La nueva talla del zapato.
     */
    public void setTallaZapato(int tallaZapato) {
        this.tallaZapato = tallaZapato;
    }

    /**
     * Obtiene el tipo de suela del zapato.
     *
     * @return El tipo de suela del zapato.
     */
    public String getTipoSuela() {
        return this.tipoSuela;
    }

    /**
     * Establece el tipo de suela del zapato.
     *
     * @param tipoSuela El nuevo tipo de suela del zapato.
     */
    public void setTipoSuela(String tipoSuela) {
        this.tipoSuela = tipoSuela;
    }

    /**
     * Obtiene el tipo de accesorio del zapato.
     *
     * @return El tipo de accesorio.
     */
    public TipoAccesorio getZapatoTipo() {
        return this.tipo;
    }

    /**
     * Establece el tipo de accesorio del zapato.
     *
     * @param zapatoTipo El nuevo tipo de accesorio del zapato.
     */
    public void setZapatoTipo(TipoAccesorio zapatoTipo) {
        this.tipo = zapatoTipo;
    }

    /**
     * Muestra los detalles del zapato.
     */
    public void mostrarDetalles() {
        System.out.println("Zapatos: " + getNombre() + ", Talla: " + getTallaZapato() + ", Tipo de suela: " + getTipoSuela());
    }
}
