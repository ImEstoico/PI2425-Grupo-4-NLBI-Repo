/**
 * Clase Bolso que representa un tipo específico de accesorio en el sistema.
 * Hereda de la clase Accesorio.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;
import tienda.Util.Enums.TipoAccesorio;

public class Bolso extends Accesorio {

    private String tipoCierre;        // Tipo de cierre del bolso
    private int capacidad;            // Capacidad del bolso en litros o unidades
    private TipoAccesorio tipo;       // Tipo de accesorio (definido en TipoAccesorio)

    /**
     * Constructor de la clase Bolso.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre del bolso.
     * @param precio El precio del bolso.
     * @param marca La marca del bolso.
     * @param descripcion La descripción del bolso.
     * @param imagen La imagen del bolso.
     * @param activo Indica si el bolso está activo.
     * @param color El color del bolso.
     * @param material El material del bolso.
     * @param estilo El estilo del bolso.
     * @param esPersonalizado Indica si el bolso es personalizado.
     * @param tipoCierre El tipo de cierre del bolso.
     * @param capacidad La capacidad del bolso.
     * @param tipo El tipo de accesorio.
     */
    public Bolso(int codigoArticulo, String nombre, float precio, String marca, String descripcion, String imagen, boolean activo,
                 String color, Material material, String estilo, boolean esPersonalizado, String tipoCierre, int capacidad, TipoAccesorio tipo) {
        super(codigoArticulo, nombre, precio, marca, descripcion, imagen, activo, color, material, estilo, esPersonalizado);
        this.tipoCierre = tipoCierre;
        this.capacidad = capacidad;
        this.tipo = tipo;
    }

    /**
     * Obtiene el tipo de cierre del bolso.
     *
     * @return El tipo de cierre del bolso.
     */
    public String getTipoCierre() {
        return this.tipoCierre;
    }

    /**
     * Establece el tipo de cierre del bolso.
     *
     * @param tipoCierre El nuevo tipo de cierre del bolso.
     */
    public void setTipoCierre(String tipoCierre) {
        this.tipoCierre = tipoCierre;
    }

    /**
     * Obtiene la capacidad del bolso.
     *
     * @return La capacidad del bolso.
     */
    public int getCapacidad() {
        return this.capacidad;
    }

    /**
     * Establece la capacidad del bolso.
     *
     * @param capacidad La nueva capacidad del bolso.
     */
    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    /**
     * Obtiene el tipo de accesorio del bolso.
     *
     * @return El tipo de accesorio.
     */
    public TipoAccesorio getTipo() {
        return this.tipo;
    }

    /**
     * Establece el tipo de accesorio del bolso.
     *
     * @param tipo El nuevo tipo de accesorio.
     */
    public void setTipo(TipoAccesorio tipo) {
        this.tipo = tipo;
    }

    /**
     * Muestra los detalles del bolso, incluyendo información heredada de Accesorio.
     *
     * @return Una cadena con los detalles del bolso.
     */
    public String mostrarDetalles() {
        return super.toString() + "Bolso{" +
                "tipoCierre='" + tipoCierre + '\'' +
                ", capacidad=" + capacidad +
                ", tipo=" + tipo +
                '}';
    }
}
