/**
 * Clase Accesorio que representa un artículo de tipo accesorio en el sistema.
 * Hereda de la clase Articulo.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;

public class Accesorio extends Articulo {
    private String estilo;          // Estilo del accesorio
    private boolean esPersonalizado; // Indica si el accesorio es personalizado
    String descripcion;            // Descripción del accesorio

    /**
     * Constructor de la clase Accesorio.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre del accesorio.
     * @param precio El precio del accesorio.
     * @param marca La marca del accesorio.
     * @param descripcion La descripción del accesorio.
     * @param imagen La imagen del accesorio.
     * @param activo Indica si el accesorio está activo.
     * @param color El color del accesorio.
     * @param material El material del accesorio.
     * @param estilo El estilo del accesorio.
     * @param esPersonalizado Indica si el accesorio es personalizado.
     */
    public Accesorio(int codigoArticulo, String nombre, float precio, String marca,
                     String descripcion, String imagen, boolean activo, String color,
                     Material material, String estilo, boolean esPersonalizado) {
        super(codigoArticulo, nombre, precio, marca, descripcion, imagen, activo, color, material);
        this.estilo = estilo;
        this.esPersonalizado = esPersonalizado;
    }

    /**
     * Obtiene el estilo del accesorio.
     *
     * @return El estilo del accesorio.
     */
    public String getEstilo() {
        return this.estilo;
    }

    /**
     * Establece el estilo del accesorio.
     *
     * @param estilo El nuevo estilo del accesorio.
     */
    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    /**
     * Verifica si el accesorio es personalizado.
     *
     * @return true si es personalizado, false en caso contrario.
     */
    public boolean isEsPersonalizado() {
        return this.esPersonalizado;
    }

    /**
     * Establece si el accesorio es personalizado.
     *
     * @param esPersonalizado true si el accesorio es personalizado, false en caso contrario.
     */
    public void setEsPersonalizado(boolean esPersonalizado) {
        this.esPersonalizado = esPersonalizado;
    }

    /**
     * Obtiene la descripción del accesorio.
     *
     * @return La descripción del accesorio.
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * Establece la descripción del accesorio.
     *
     * @param descripcion La nueva descripción del accesorio.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
