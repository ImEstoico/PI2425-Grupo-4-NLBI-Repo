/**
 * Clase Chaqueta que representa un tipo específico de ropa en el sistema.
 * Hereda de la clase Ropa.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;

public class Chaqueta extends Ropa {
    private boolean impermeable; // Indica si la chaqueta es impermeable

    /**
     * Constructor de la clase Chaqueta.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre de la chaqueta.
     * @param precio El precio de la chaqueta.
     * @param marca La marca de la chaqueta.
     * @param descripcion La descripción de la chaqueta.
     * @param imagen La imagen de la chaqueta.
     * @param activo Indica si la chaqueta está activa.
     * @param color El color de la chaqueta.
     * @param material El material de la chaqueta.
     * @param talla La talla de la chaqueta.
     * @param tipoCierre El tipo de cierre de la chaqueta.
     * @param impermeable Indica si la chaqueta es impermeable.
     */
    public Chaqueta(int codigoArticulo, String nombre, float precio, String marca, String descripcion, String imagen,
                    boolean activo, String color, Material material, int talla, String tipoCierre, boolean impermeable) {
        super(codigoArticulo, nombre, precio, marca, descripcion, imagen, activo, color, material, talla, tipoCierre);
        this.impermeable = impermeable;
    }

    /**
     * Muestra los detalles de la chaqueta.
     */
    public void mostrarDetalles() {
        System.out.println("Chaqueta: " + nombre + ", Impermeable: " + (impermeable ? "Sí" : "No"));
    }

    /**
     * Verifica si la chaqueta es impermeable.
     *
     * @return true si la chaqueta es impermeable, false en caso contrario.
     */
    public boolean isImpermeable() {
        return impermeable;
    }

    /**
     * Establece si la chaqueta es impermeable.
     *
     * @param impermeable true si la chaqueta es impermeable, false en caso contrario.
     */
    public void setImpermeable(boolean impermeable) {
        this.impermeable = impermeable;
    }
}
