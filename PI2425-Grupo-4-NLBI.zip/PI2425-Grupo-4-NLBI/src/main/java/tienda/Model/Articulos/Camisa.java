/**
 * Clase Camisa que representa un tipo específico de ropa en el sistema.
 * Hereda de la clase Ropa.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;
import tienda.Model.Articulos.Ropa;

public class Camisa extends Ropa {
    private String tipoManga;         // Tipo de manga de la camisa
    private boolean esEstampada;      // Indica si la camisa es estampada

    /**
     * Constructor de la clase Camisa.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre de la camisa.
     * @param precio El precio de la camisa.
     * @param marca La marca de la camisa.
     * @param descripcion La descripción de la camisa.
     * @param imagen La imagen de la camisa.
     * @param activo Indica si la camisa está activa.
     * @param color El color de la camisa.
     * @param material El material de la camisa.
     * @param talla La talla de la camisa.
     * @param tipoCierre El tipo de cierre de la camisa.
     * @param tipoManga El tipo de manga de la camisa.
     * @param esEstampada Indica si la camisa es estampada.
     */
    public Camisa(int codigoArticulo, String nombre, float precio, String marca, String descripcion, String imagen,
                  boolean activo, String color, Material material, int talla, String tipoCierre, String tipoManga, boolean esEstampada) {
        super(codigoArticulo, nombre, precio, marca, descripcion, imagen, activo, color, material, talla, tipoCierre);
        this.tipoManga = tipoManga;
        this.esEstampada = esEstampada;
    }

    /**
     * Muestra los detalles de la camisa.
     */
    public void mostrarDetalles() {
        System.out.println("Camisa: " + nombre + ", Tipo de Manga: " + tipoManga + ", Estampada: " + (esEstampada ? "Sí" : "No"));
    }

    /**
     * Obtiene el tipo de manga de la camisa.
     *
     * @return El tipo de manga de la camisa.
     */
    public String getTipoManga() {
        return this.tipoManga;
    }

    /**
     * Establece el tipo de manga de la camisa.
     *
     * @param tipoManga El nuevo tipo de manga de la camisa.
     */
    public void setTipoManga(String tipoManga) {
        this.tipoManga = tipoManga;
    }

    /**
     * Verifica si la camisa es estampada.
     *
     * @return true si la camisa es estampada, false en caso contrario.
     */
    public boolean isEsEstampada() {
        return this.esEstampada;
    }

    /**
     * Establece si la camisa es estampada.
     *
     * @param esEstampada true si la camisa es estampada, false en caso contrario.
     */
    public void setEsEstampada(boolean esEstampada) {
        this.esEstampada = esEstampada;
    }
}
