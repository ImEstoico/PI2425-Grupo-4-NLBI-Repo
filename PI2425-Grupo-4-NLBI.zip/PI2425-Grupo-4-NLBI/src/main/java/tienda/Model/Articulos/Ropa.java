/**
 * Clase Ropa que representa un tipo general de artículo en el sistema.
 * Hereda de la clase Articulo.
 */
package tienda.Model.Articulos;

import tienda.Model.Catalogo.Material;

public class Ropa extends Articulo {
    protected int talla;             // Talla de la ropa
    protected String tipoCierre;     // Tipo de cierre de la ropa
    protected enum TipoRopa {};       // Enumeración para tipos de ropa (actualmente vacía)

    /**
     * Constructor de la clase Ropa.
     *
     * @param codigoArticulo El código del artículo.
     * @param nombre El nombre de la ropa.
     * @param precio El precio de la ropa.
     * @param marca La marca de la ropa.
     * @param descripcion La descripción de la ropa.
     * @param imagen La imagen de la ropa.
     * @param activo Indica si la ropa está activa.
     * @param color El color de la ropa.
     * @param material El material de la ropa.
     * @param talla La talla de la ropa.
     * @param tipoCierre El tipo de cierre de la ropa.
     */
    public Ropa(int codigoArticulo, String nombre, float precio, String marca, String descripcion,
                String imagen, boolean activo, String color, Material material, int talla, String tipoCierre) {
        super(codigoArticulo, nombre, precio, marca, descripcion, imagen, activo, color, material);
        this.talla = talla;
        this.tipoCierre = tipoCierre;
    }

    /**
     * Obtiene la talla de la ropa.
     *
     * @return La talla de la ropa.
     */
    public int getTalla() {
        return this.talla;
    }

    /**
     * Establece la talla de la ropa.
     *
     * @param talla La nueva talla de la ropa.
     */
    public void setTalla(int talla) {
        this.talla = talla;
    }

    /**
     * Obtiene el color de la ropa.
     *
     * @return El color de la ropa.
     */
    public String getColor() {
        return this.color;
    }

    /**
     * Establece el color de la ropa.
     *
     * @param color El nuevo color de la ropa.
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Obtiene el tipo de cierre de la ropa.
     *
     * @return El tipo de cierre de la ropa.
     */
    public String getTipoCierre() {
        return this.tipoCierre;
    }

    /**
     * Establece el tipo de cierre de la ropa.
     *
     * @param tipoCierre El nuevo tipo de cierre de la ropa.
     */
    public void setTipoCierre(String tipoCierre) {
        this.tipoCierre = tipoCierre;
    }
}
