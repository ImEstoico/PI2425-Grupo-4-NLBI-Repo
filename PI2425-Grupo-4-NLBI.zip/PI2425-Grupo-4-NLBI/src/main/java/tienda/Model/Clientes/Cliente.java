/**
 * Clase Cliente que representa un cliente del sistema, extendiendo la clase Usuario.
 * Implementa Serializable para permitir la serialización de objetos de esta clase.
 */
package tienda.Model.Clientes;

import tienda.Model.Pedidos.Metodo_Pago;
import tienda.Model.Pedidos.Pedido;
import tienda.Model.Usuarios.Usuario;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Cliente extends Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    private int numeroPedidos; // Número de pedidos realizados por el cliente
    private boolean tieneTarjetaFidelizacion; // Indica si el cliente tiene tarjeta de fidelización
    private String direccionEnvio; // Dirección de envío del cliente
    private Metodo_Pago metodoPago; // Método de pago preferido del cliente
    private ArrayList<Pedido> pedidos; // Lista de pedidos realizados por el cliente

    /**
     * Constructor de la clase Cliente.
     *
     * @param dni El DNI del cliente.
     * @param apellidos Los apellidos del cliente.
     * @param nombre El nombre del cliente.
     * @param telefono El número de teléfono del cliente.
     * @param direccion La dirección del cliente.
     * @param email El email del cliente.
     * @param activo Indica si el cliente está activo.
     * @param pass La contraseña del cliente.
     * @param f_nacimiento La fecha de nacimiento del cliente.
     * @param numeroPedidos El número de pedidos realizados.
     * @param tieneTarjetaFidelizacion Indica si tiene tarjeta de fidelización.
     * @param direccionEnvio La dirección de envío del cliente.
     * @param metodoPago El método de pago preferido del cliente.
     * @param pedidos La lista de pedidos realizados por el cliente.
     */
    public Cliente(String dni, String apellidos, String nombre, int telefono, String direccion, String email,
                   boolean activo, String pass, LocalDate f_nacimiento, int numeroPedidos, boolean tieneTarjetaFidelizacion,
                   String direccionEnvio, Metodo_Pago metodoPago, ArrayList<Pedido> pedidos) {
        super(dni, apellidos, nombre, telefono, direccion, email, activo, pass, f_nacimiento);
        this.numeroPedidos = numeroPedidos;
        this.tieneTarjetaFidelizacion = tieneTarjetaFidelizacion;
        this.direccionEnvio = direccionEnvio;
        this.metodoPago = metodoPago;
        this.pedidos = pedidos;
    }

    /**
     * Obtiene el número de pedidos realizados por el cliente.
     *
     * @return El número de pedidos.
     */
    public int getNumeroPedidos() {
        return this.numeroPedidos;
    }

    /**
     * Indica si el cliente tiene tarjeta de fidelización.
     *
     * @return true si tiene tarjeta de fidelización, false en caso contrario.
     */
    public boolean isTieneTarjetaFidelizacion() {
        return this.tieneTarjetaFidelizacion;
    }

    /**
     * Obtiene la dirección de envío del cliente.
     *
     * @return La dirección de envío.
     */
    public String getDireccionEnvio() {
        return this.direccionEnvio;
    }

    /**
     * Obtiene el método de pago preferido del cliente.
     *
     * @return El método de pago.
     */
    public Metodo_Pago getMetodoPago() {
        return this.metodoPago;
    }

    /**
     * Establece el número de pedidos realizados por el cliente.
     *
     * @param numeroPedidos El nuevo número de pedidos.
     */
    public void setNumeroPedidos(int numeroPedidos) {
        this.numeroPedidos = numeroPedidos;
    }

    /**
     * Establece si el cliente tiene tarjeta de fidelización.
     *
     * @param tieneTarjetaFidelizacion true si tiene tarjeta de fidelización, false en caso contrario.
     */
    public void setTieneTarjetaFidelizacion(boolean tieneTarjetaFidelizacion) {
        this.tieneTarjetaFidelizacion = tieneTarjetaFidelizacion;
    }

    /**
     * Establece la dirección de envío del cliente.
     *
     * @param direccionEnvio La nueva dirección de envío.
     */
    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    /**
     * Establece el método de pago preferido del cliente.
     *
     * @param metodoPago El nuevo método de pago.
     */
    public void setMetodoPago(Metodo_Pago metodoPago) {
        this.metodoPago = metodoPago;
    }

    /**
     * Obtiene la lista de pedidos realizados por el cliente.
     *
     * @return La lista de pedidos.
     */
    public ArrayList<Pedido> getPedidos() {
        return this.pedidos;
    }

    /**
     * Establece la lista de pedidos realizados por el cliente.
     *
     * @param pedidos La nueva lista de pedidos.
     */
    public void setPedidos(ArrayList<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    /**
     * Realiza un pedido si el cliente tiene pedidos registrados.
     */
    public void realizarPedido() {
        if (numeroPedidos > 0) {
            System.out.println("Realizando pedido...");
        } else {
            System.out.println("Debe registrarse como cliente primero.");
        }
    }

    /**
     * Visualiza los artículos disponibles en la tienda.
     */
    public void verArticulos() {
        System.out.println("Visualizando artículos de la tienda...");
    }
}
