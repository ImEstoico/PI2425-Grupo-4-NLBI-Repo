/**
 * Clase Clientela que gestiona una colección de clientes.
 */
package tienda.Model.Clientes;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Clientela {
    private List<Cliente> clientes; // Lista de clientes

    /**
     * Constructor de la clase Clientela.
     * Inicializa la lista de clientes.
     */
    public Clientela() {
        this.clientes = new ArrayList<>();
    }

    /**
     * Obtiene la lista de clientes.
     *
     * @return La lista de clientes.
     */
    public List<Cliente> getClientes() {
        return clientes;
    }

    /**
     * Establece la lista de clientes.
     *
     * @param clientes La nueva lista de clientes.
     */
    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    // Métodos CRUD

    /**
     * Agrega un nuevo cliente a la lista.
     *
     * @param cliente El cliente a agregar.
     */
    public void addCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    /**
     * Obtiene un cliente por su DNI.
     *
     * @param dni El DNI del cliente a buscar.
     * @return El cliente encontrado o null si no existe.
     */
    public Cliente getCliente(String dni) {
        return clientes.stream()
                .filter(cliente -> cliente.getDni().equals(dni))
                .findFirst()
                .orElse(null);
    }

    /**
     * Actualiza la información de un cliente existente.
     *
     * @param cliente El cliente con la información actualizada.
     */
    public void updateCliente(Cliente cliente) {
        Cliente existingCliente = getCliente(cliente.getDni());
        if (existingCliente != null) {
            existingCliente.setDni(cliente.getDni());
            existingCliente.setApellidos(cliente.getApellidos());
            existingCliente.setNombre(cliente.getNombre());
            existingCliente.setTelefono(cliente.getTelefono());
            existingCliente.setDireccion(cliente.getDireccion());
            existingCliente.setEmail(cliente.getEmail());
            existingCliente.setActivo(cliente.isActivo());
            existingCliente.setPass(cliente.getPass());
            existingCliente.setF_nacimiento(cliente.getF_nacimiento());
            existingCliente.setNumeroPedidos(cliente.getNumeroPedidos());
            existingCliente.setTieneTarjetaFidelizacion(cliente.isTieneTarjetaFidelizacion());
            existingCliente.setDireccionEnvio(cliente.getDireccionEnvio());
            existingCliente.setMetodoPago(cliente.getMetodoPago());
            existingCliente.setPedidos(cliente.getPedidos());
        }
    }

    /**
     * Elimina un cliente de la lista por su DNI.
     *
     * @param dni El DNI del cliente a eliminar.
     */
    public void deleteCliente(String dni) {
        clientes.removeIf(cliente -> cliente.getDni().equals(dni));
    }

    // Métodos de búsqueda

    /**
     * Busca un cliente por su DNI.
     *
     * @param dni El DNI del cliente a buscar.
     * @return El cliente encontrado o null si no existe.
     */
    public Cliente buscarPorDni(String dni) {
        return getCliente(dni);
    }

    /**
     * Filtra la lista de clientes por su método de pago.
     *
     * @param metodoPago El método de pago a filtrar.
     * @return La lista de clientes que utilizan el método de pago especificado.
     */
    public List<Cliente> filtrarPorMetodoPago(String metodoPago) {
        return clientes.stream()
                .filter(cliente -> cliente.getMetodoPago().equals(metodoPago))
                .collect(Collectors.toList());
    }

    /**
     * Filtra la lista de clientes por nombre y apellidos.
     *
     * @param nombre El nombre a filtrar.
     * @param apellidos Los apellidos a filtrar.
     * @return La lista de clientes que coinciden con el nombre y apellidos especificados.
     */
    public List<Cliente> filtrarPorNombreYApellidos(String nombre, String apellidos) {
        return clientes.stream()
                .filter(cliente -> cliente.getNombre().equals(nombre) && cliente.getApellidos().equals(apellidos))
                .collect(Collectors.toList());
    }
}
