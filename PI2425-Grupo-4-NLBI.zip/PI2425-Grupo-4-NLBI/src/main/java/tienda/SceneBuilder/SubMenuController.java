package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class SubMenuController {

    @FXML
    private Button btnPanelAdmin;

    @FXML
    void OnActionBtnPanelAdmin(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderPanelAdmin");
    }

}
