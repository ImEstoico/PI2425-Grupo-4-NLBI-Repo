package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import tienda.Model.Usuarios.Usuario;

import java.io.IOException;

public class InfousrController {

    @FXML
    private Button BackButton;

    @FXML
    private TextArea TaNumPed;

    @FXML
    private TextArea taDNI;

    @FXML
    private TextArea taDirEnvio;

    @FXML
    private TextArea taDireccion;

    @FXML
    private TextArea taEmail;

    @FXML
    private TextArea taFechaNac;

    @FXML
    private TextArea taNomApe;

    @FXML
    private TextArea taTarjetaFide;

    @FXML
    private TextArea taTelefono;

    private Usuario usuario;

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        mostrarDatosUsuario();
    }

    private void mostrarDatosUsuario() {
        if (usuario != null) {
            taNomApe.setText(usuario.getNombre());
            taDNI.setText(usuario.getDni());
            taDireccion.setText(usuario.getDireccion());
            taDirEnvio.setText(usuario.getDireccion());
            taEmail.setText(usuario.getEmail());
            taTelefono.setText(String.valueOf(usuario.getTelefono()));
            taFechaNac.setText(usuario.getFechaNacimiento().toString());
            taTarjetaFide.setText(null);
            TaNumPed.setText(null);
        }
    }

    @FXML
    void OnActionBackButton(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderListaUsuarios");
    }
}
