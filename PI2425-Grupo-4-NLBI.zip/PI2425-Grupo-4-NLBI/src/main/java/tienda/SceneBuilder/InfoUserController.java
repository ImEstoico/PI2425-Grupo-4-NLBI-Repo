package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import tienda.Model.Clientes.Cliente;
import tienda.dao.ClienteDAO;
import tienda.dao.LineaPedidoDAO;
import tienda.dao.PedidoDAO;

import java.io.IOException;

public class InfoUserController {

    @FXML
    private Button btnBackButton;

    @FXML
    private Label labelDNI;

    @FXML
    private Label labelDir;

    @FXML
    private Label labelDirEnv;

    @FXML
    private Label labelEmail;

    @FXML
    private Label labelFechaNacimiento;

    @FXML
    private Label labelNumPedidos;

    @FXML
    private Label labelTarjFidel;

    @FXML
    private Label labelTlf;

    @FXML
    public void initialize() {
        labelDNI.setText(HelloApplication.getUser().getDni());
        labelDir.setText(HelloApplication.getUser().getDireccion());
        labelDirEnv.setText(parseCliente().getDireccionEnvio());
        labelEmail.setText(HelloApplication.getUser().getEmail());
        labelTlf.setText(String.valueOf(HelloApplication.getUser().getTelefono()));
        labelTarjFidel.setText(parseCliente().isTieneTarjetaFidelizacion() ? "Tiene" : "No tiene" );
        labelFechaNacimiento.setText(HelloApplication.getUser().getFechaNacimiento());
        labelNumPedidos.setText(getNumPedidos().toString());

    }

    private Cliente parseCliente(){
        ClienteDAO dao = new ClienteDAO();
        return dao.obtenerPorId(HelloApplication.getUser().getDni());
    }

    private Integer getNumPedidos() {
        PedidoDAO dao = new PedidoDAO();
        return dao.obtenerCantPedidosPorCliente(HelloApplication.getUser().getDni());
    }

    @FXML
    void OnActionBtnBackButton(ActionEvent event) throws IOException {
        HelloApplication.setRoot("MenuPrincipal");
    }

}

