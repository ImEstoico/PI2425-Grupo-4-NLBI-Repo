package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.io.IOException;

public class SeccionProductoController {

    @FXML
    private Button btnAddCarrito;

    @FXML
    private Button btnVolverSeccionProducto;

    @FXML
    private Hyperlink hlBlusaDeFlores;

    @FXML
    private Hyperlink hlCamisas;

    @FXML
    private Hyperlink hlRopa;

    @FXML
    private ImageView ivSeccionArticulo;

    @FXML
    private ImageView ivSecondhand;

    @FXML
    private Label lbEtiqueta;

    @FXML
    private Label lbPrecio;

    @FXML
    private Label lbProducto;

    @FXML
    private Label lbTextoProducto;

    @FXML
    private Label lbdescripcion;

    @FXML
    private Separator separadorDescripcion;

    @FXML
    private Separator separadorEtiqueta;

    @FXML
    private TextField tfBuscar;

    @FXML
    void OnActionBtnAddCarrito(ActionEvent event) {

    }

    @FXML
    void OnActionBtnVolverSeccionProducto(ActionEvent event) throws IOException {
        HelloApplication.setRoot("Catalogo");
    }

}

