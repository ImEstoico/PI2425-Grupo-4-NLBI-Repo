package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import tienda.Model.Articulos.Articulo;
import tienda.Model.Pedidos.LineaPedido;
import tienda.Model.Pedidos.Pedido;
import tienda.dao.ArticuloDAO;
import tienda.dao.LineaPedidoDAO;
import tienda.dao.PedidoDAO;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;

public class CatalogoController {

    @FXML
    private Button btAnadirCarrito1;

    @FXML
    private Button btnAnadirCarrito;

    @FXML
    private Button btnArticuloAccesorio;

    @FXML
    private Button btnArticuloRopa;

    @FXML
    private Button btnFiltroBolsos;

    @FXML
    private Button btnFiltroCamisas;

    @FXML
    private Button btnFiltroChaquetas;

    @FXML
    private Button btnFiltroPantalones;

    @FXML
    private Button btnFiltroZapatos;

    @FXML
    private TextField tfNombreArticulo;

    @FXML
    private TextField tfNombreArticulo1;

    @FXML
    private TextField tfPrecioArticulo1;

    @FXML
    private TextField txtPrecioArticulo;

    @FXML
    void OnActionBtnAnadirCarrito(ActionEvent event) {

    }

    @FXML
    public void initialize() {
        btnAnadirCarrito.setOnAction(event -> {
            add(1);
        });
    }

    @FXML
    void add(Integer codart) {
        LineaPedidoDAO cart = new LineaPedidoDAO();
        ArticuloDAO art = new ArticuloDAO();
        PedidoDAO ped = new PedidoDAO();
        Articulo artic = art.obtenerPorId(codart);
        Pedido pedido = ped.obtenerPedidoActualPorUsuario(HelloApplication.getUser().getDni());
        if (pedido == null){
            Pedido pedido1 = new Pedido(0, Date.from(Instant.now()), HelloApplication.parseCliente().getDireccionEnvio(), HelloApplication.getUser().getDni(), HelloApplication.parseCliente().getMetodoPago(), new ArrayList<>(), new ArrayList<>(), "En proceso");
            ped.insertar(pedido1);
            pedido1 = ped.obtenerPedidoActualPorUsuario(HelloApplication.getUser().getDni());
            LineaPedido lineaPedido = new LineaPedido(pedido1.getNumeroPedido(), artic);
            cart.insertar(lineaPedido);
        } else {
            LineaPedido lineaPedido = new LineaPedido(pedido.getNumeroPedido(), artic);
            cart.insertar(lineaPedido);
        }
    }


    @FXML
    void OnActionBackButton(ActionEvent event) throws IOException {
        HelloApplication.setRoot("menuPrincipal");

    }
    @FXML
    void OnActionBtnArticuloAccesorio(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderSeccionProducto");
    }

    @FXML
    void OnActionBtnArticuloRopa(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderSeccionProducto");
    }

    @FXML
    void OnActionBtnFiltroBolso(ActionEvent event) {

    }

    @FXML
    void OnActionBtnFiltroCamisas(ActionEvent event) {

    }

    @FXML
    void OnActionBtnFiltroChaquetas(ActionEvent event) {

    }

    @FXML
    void OnActionBtnFiltroPantalones(ActionEvent event) {

    }

    @FXML
    void OnActionBtnFiltroZapatos(ActionEvent event) {

    }

    @FXML
    void OnActionTfNombreArticulo(ActionEvent event) {

    }

    @FXML
    void OnActionTfNombreArticulo1(ActionEvent event) {

    }

    @FXML
    void OnActionTfPrecioArticulo(ActionEvent event) {

    }

    @FXML
    void OnActionTxtPrecioArticulo(ActionEvent event) {

    }

}
