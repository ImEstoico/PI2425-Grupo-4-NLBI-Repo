package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

import java.io.IOException;

public class PanelAdminController {

    @FXML
    private Button btnAdminEmpleados;

    @FXML
    private Button btnAdminProductos;

    @FXML
    private Button btnAdminUsuarios;

    @FXML
    private Button btnAltaProducto;

    @FXML
    private Button btnVolverPanelAdmin;

    @FXML
    private ImageView imagePerchaAdmin;

    @FXML
    private Label lbBienvenido;

    @FXML
    private Label lbPanelAdmin;

    @FXML
    void OnActionBtnAdminEmpleados(ActionEvent event) throws IOException {
        HelloApplication.setRoot("ListaEmpleado");
    }

    @FXML
    void OnActionBtnAdminProductos(ActionEvent event) {

    }

    @FXML
    void OnActionBtnAdminUsuarios(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderListaUsuarios");
    }

    @FXML
    void OnActionBtnAltaProducto(ActionEvent event) throws IOException {
        HelloApplication.setRoot("AltaProducto");

    }

    @FXML
    void OnActionBtnVolverPanelAdmin(ActionEvent event) throws IOException {
        HelloApplication.setRoot("Sub_Menú");
    }

}
