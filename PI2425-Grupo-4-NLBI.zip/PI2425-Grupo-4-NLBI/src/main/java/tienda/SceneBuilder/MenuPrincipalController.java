package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class MenuPrincipalController {

    @FXML
    private ToggleGroup Pago;

    @FXML
    private AnchorPane VBbase;

    @FXML
    private Button bntDevoluciones;

    @FXML
    private Button btnAccesorio;

    @FXML
    private Button btnEnvios;

    @FXML
    private Button btnEstado;

    @FXML
    private Button btnExtMenu;

    @FXML
    private Button btnInciarRegistro;

    @FXML
    private Button btnPregunta;

    @FXML
    private Label btnPrguntas;

    @FXML
    private Button btnRopa;

    @FXML
    private ImageView imgInst;

    @FXML
    private ImageView imgLogo;

    @FXML
    private RadioButton rbtnBiz;

    @FXML
    private RadioButton rbtnEfect;

    @FXML
    private RadioButton rbtnTarg;

    @FXML
    private TextField tfBuscar;

    @FXML
    void OnActionBtnAccesorio(ActionEvent event) throws IOException {
        HelloApplication.setRoot("Catalogo");
    }

    @FXML
    void OnActionBtnBuscar(ActionEvent event) {

    }

    @FXML
    void OnActionBtnCarritoCompra(ActionEvent event) throws IOException {
        HelloApplication.setRoot("Carrito");
    }

    @FXML
    void OnActionBtnExtMenu(ActionEvent event) throws IOException {
        HelloApplication.setRoot("Sub_Menú");
    }

    @FXML
    void OnActionBtnInciarRegistro(ActionEvent event) throws IOException {
        HelloApplication.setRoot("infousr");

    }

    @FXML
    void OnActionBtnRopa(ActionEvent event) throws IOException {
        HelloApplication.setRoot("Catalogo");
    }

    @FXML
    void OnActionTfBuscar(ActionEvent event) {

    }

}
