package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import tienda.dao.EmpleadoDAO;

import java.io.IOException;

public class ListaUsuariosController {

    @FXML
    private Button btnEliminarUsuario1;

    @FXML
    private Button btnEliminarUsuario2;

    @FXML
    private Button btnEliminarUsuario3;

    @FXML
    private Button btnEliminarUsuario4;

    @FXML
    private Button btnGuardarUsuarios;

    @FXML
    private Button btnVolverListaUsuarios;

    @FXML
    private CheckBox checkUsuario1;

    @FXML
    private CheckBox checkUsuario2;

    @FXML
    private CheckBox checkUsuario3;

    @FXML
    private CheckBox checkUsuario4;

    @FXML
    private Label lbCliente1;

    @FXML
    private Label lbCliente2;

    @FXML
    private Label lbCliente3;

    @FXML
    private Label lbCliente4;

    @FXML
    private Label lbEmpleados;

    @FXML
    private Label lbListausuarios;

    @FXML
    private Label lbUsuario1;

    @FXML
    private Label lbUsuario2;

    @FXML
    private Label lbUsuario3;

    @FXML
    private Label lbUsuario4;

    @FXML
    private Pane paneUsuario1;

    @FXML
    private Pane paneUsuario2;

    @FXML
    private Pane paneUsuario3;

    @FXML
    private Pane paneUsuario4;

    @FXML
    void OnActionBtnEliminarUsuario1(ActionEvent event) {

    }

    @FXML
    void OnActionBtnEliminarUsuario2(ActionEvent event) {

    }

    @FXML
    void OnActionBtnEliminarUsuario3(ActionEvent event) {

    }

    @FXML
    void OnActionBtnEliminarUsuario4(ActionEvent event) {

    }

    @FXML
    void OnActionBtnGuardarUsuarios(ActionEvent event) {

    }

    @FXML
    void OnActionCheckAddUsuario1(ActionEvent event) {

    }

    @FXML
    void OnActionCheckAddUsuario2(ActionEvent event) {

    }

    @FXML
    void OnActionCheckAddUsuario3(ActionEvent event) {

    }

    @FXML
    void OnActionCheckAddUsuario4(ActionEvent event) {

    }

    @FXML
    void OnActionBtnVolverListaUsuarios(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderPanelAdmin");
    }

}
