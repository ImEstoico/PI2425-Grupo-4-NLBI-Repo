package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import tienda.SceneBuilder.HelloApplication;
import tienda.Model.Articulos.Articulo;
import tienda.Model.Pedidos.Carrito;
import tienda.Model.Pedidos.Pedido;
import tienda.dao.PedidoDAO;

import java.io.IOException;
import java.util.List;

public class CarritoController {

    @FXML private TextArea ListaCarrito1;
    @FXML private TextArea ListaCarrito2;
    @FXML private TextArea ListaCarrito3;
    @FXML private TextArea ListaCarrito4;
    @FXML private Label PrecioTotal;

    @FXML private Button btnRealizarPedido;
    @FXML private Button btnVolverCarrito;

    private Carrito carrito;

    @FXML
    public void initialize() {
        carrito = new Carrito();
        cargarArticulos();
        actualizarPrecioTotal();
    }

    @FXML
    void OnActionBtnVolverCarrito(ActionEvent event) throws IOException {
        HelloApplication.setRoot("MenuPrincipal");
    }

    @FXML
    void OnActionBtnRealizarPedido(ActionEvent event) {
        PedidoDAO pedidoDAO = new PedidoDAO();
        String dni = HelloApplication.getUser().getDni();

        // Obtener el pedido actual
        Pedido pedidoActual = pedidoDAO.obtenerPedidoActualPorUsuario(dni);

        if (pedidoActual != null) {
            // Confirmar el pedido actual
            pedidoDAO.confirmarPedido(pedidoActual.getNumeroPedido());
            System.out.println("Su pedido " + pedidoActual.getNumeroPedido() + " se ha realizado con éxito.");
        } else {
            System.out.println("No hay pedido activo para confirmar.");
        }

        // Limpiar carrito después
        carrito = new Carrito();
        cargarArticulos();
        actualizarPrecioTotal();
    }

    @FXML
    void OnActionEliminar1(ActionEvent event) {
        eliminarArticulo(0);
    }

    @FXML
    void OnActionEliminar2(ActionEvent event) {
        eliminarArticulo(1);
    }

    @FXML
    void OnActionEliminar3(ActionEvent event) {
        eliminarArticulo(2);
    }

    @FXML
    void OnActionEliminar4(ActionEvent event) {
        eliminarArticulo(3);
    }

    @FXML
    void OnActionRecargarCarrito(ActionEvent event) {
        carrito = new Carrito();
        cargarArticulos();
        actualizarPrecioTotal();
    }

    private void cargarArticulos() {
        List<Articulo> articulos = carrito.getArticulos();

        TextArea[] areas = {ListaCarrito1, ListaCarrito2, ListaCarrito3, ListaCarrito4};

        for (int i = 0; i < areas.length; i++) {
            if (i < articulos.size()) {
                Articulo art = articulos.get(i);
                areas[i].setText(art.getNombre() + " - " + art.getPrecio() + "€");
            } else {
                areas[i].clear();
            }
        }
    }

    private void eliminarArticulo(int index) {
        carrito.eliminarArticuloPorIndice(index);
        cargarArticulos();
        actualizarPrecioTotal();
    }

    private void actualizarPrecioTotal() {
        double total = carrito.calcularTotal();
        PrecioTotal.setText("Total: " + String.format("%.2f", total) + " €");
    }
}
