package tienda.SceneBuilder;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import tienda.Model.Clientes.Cliente;
import tienda.dao.ClienteDAO;

import java.io.IOException;

public class LoginController {

    private static Stage stage2;


    @FXML
    private Hyperlink HpOlvidoContrasena;

    @FXML
    private PasswordField TfContrasena;

    @FXML
    private TextField TfLogin;



    @FXML
    private Button btnLogin;

    @FXML
    private Button btnRegistrarse;





    @FXML
    void OnActionBtnLogin(ActionEvent event) {
        try {
            if (TfLogin.getText().isEmpty() || TfContrasena.getText().isEmpty()) {
                System.out.println("Por favor, completa todos los campos.");
                return;
            }

            String email = TfLogin.getText();
            String contrasenya = TfContrasena.getText();

            ClienteDAO clienteDAO = new ClienteDAO();
            Cliente cliente1 = clienteDAO.autenticarCliente(email, contrasenya);

            if (cliente1 != null) {
                HelloApplication.setUser(cliente1);
                HelloApplication.setRoot("MenuPrincipal");
            } else {
                System.out.println("Error al iniciar sesión. Usuario o contraseña incorrectos.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void OnActionPanicLOGIN(ActionEvent event) {
        String email = "cliente@prueba.com";
        String contrasenya = "12345";

        ClienteDAO clienteDAO = new ClienteDAO();
        Cliente cliente1 = clienteDAO.autenticarCliente(email, contrasenya);

        if (cliente1 != null) {
            HelloApplication.setUser(cliente1);
            try {
                HelloApplication.setRoot("MenuPrincipal");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            System.out.println("Error al iniciar sesión. Usuario o contraseña incorrectos.");
        }
    }

    @FXML
    void OnActionBtnRegistrarse(ActionEvent event) throws IOException {
        HelloApplication.setRoot("Registro");
    }


    @FXML
    void OnActionPanic(ActionEvent event) throws IOException {
        HelloApplication.setRoot("menuPrincipal");
    }

    @FXML
    void OnActionHpOlvidoContrasena(ActionEvent event) throws IOException {
    }

    @FXML
    void OnActionTfContrasena(ActionEvent event) {

    }

    @FXML
    void OnActionTfLogin(ActionEvent event) {

    }

}
