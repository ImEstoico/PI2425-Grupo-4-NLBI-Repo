package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

import java.io.IOException;

public class ListaEmpleadosController {

    @FXML
    private Button btnBack;

    @FXML
    private Button btnEditarEmpleado;

    @FXML
    private Button btnQuitar;

    @FXML
    private RadioButton rbtnPrivilegios;

    @FXML
    private TextField tfNombreEmpleadoLista;

    @FXML
    void OnActionBtnBack(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderPanelAdmin");
    }

    @FXML
    void OnActionBtnEditarEmpleado(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderEditarEmpleado");
    }

    @FXML
    void OnActionBtnQuitar(ActionEvent event) {

    }

    @FXML
    void OnActionRbtnPrivilegios(ActionEvent event) {

    }

    @FXML
    void OnActionTfNombreEmpleadoLista(ActionEvent event) {

    }

}
