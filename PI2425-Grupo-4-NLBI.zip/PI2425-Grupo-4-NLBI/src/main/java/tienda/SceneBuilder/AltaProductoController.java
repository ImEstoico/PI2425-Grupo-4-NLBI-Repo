package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import tienda.Model.Catalogo.Material;
import tienda.dao.ArticuloDAO;
import tienda.Model.Articulos.*;

import java.io.IOException;

public class AltaProductoController {

    @FXML
    private Button BtnGuardarCambios;

    @FXML
    private TextField TfDepartamento;

    @FXML
    private TextArea TfDescripcion;

    @FXML
    private TextField TfGrupoProducto;

    @FXML
    private TextField TfNombre;

    @FXML
    private TextField TfPrecioDeCoste;

    @FXML
    private TextField TfPrecioVenta;

    @FXML
    private TextField TfPrecioVenta1; // Este parece duplicado, aclárame si quieres usarlo

    @FXML
    private TextField TfPvpRecomendado;

    @FXML
    private TextField Tfnumero;

    @FXML
    private Button btnGuardarYPublicar;

    private final ArticuloDAO articuloDAO = new ArticuloDAO();

    @FXML
    void OnActionBtnGuardarCambios(ActionEvent event) {
        guardarArticulo(false);
    }

    @FXML
    void OnActionBtnGuardarYPublicar(ActionEvent event) {
        guardarArticulo(true);
    }

    private void guardarArticulo(boolean publicar) {
        try {
            Articulo articulo = new Articulo();

            articulo.setCodigoArticulo(Integer.parseInt(Tfnumero.getText()));
            articulo.setNombre(TfNombre.getText());
            articulo.setPrecio(Float.parseFloat(TfPrecioVenta.getText()));
            articulo.setMarca(TfGrupoProducto.getText());
            articulo.setDescripcion(TfDescripcion.getText());
            articulo.setImagen("default.jpg");
            articulo.setColor(TfDepartamento.getText());
            articulo.setActivo(publicar);
            articulo.setMaterial(null);

            articuloDAO.insertar(articulo);

            System.out.println(" Artículo guardado en la base de datos.");
        } catch (Exception e) {
            System.err.println(" Error al guardar el artículo: " + e.getMessage());
        }
    }

    @FXML
    void backbutton(ActionEvent event) throws IOException {
        HelloApplication.setRoot("SceneBuilderPanelAdmin");
    }
}
