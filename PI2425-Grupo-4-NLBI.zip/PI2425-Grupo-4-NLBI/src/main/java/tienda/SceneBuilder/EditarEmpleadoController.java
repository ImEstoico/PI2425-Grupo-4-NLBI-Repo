package tienda.SceneBuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class EditarEmpleadoController {

    @FXML
    private Button btnEditarEmpleado;

    @FXML
    private Button btnVolverEditarEmpleado;

    @FXML
    private RadioButton checkLvl1;

    @FXML
    private RadioButton checkLvl2;

    @FXML
    private RadioButton checkLvl3;

    @FXML
    private RadioButton checkMarketing;

    @FXML
    private CheckBox checkPrivilegios;

    @FXML
    private RadioButton checkProgramador;

    @FXML
    private RadioButton checkR1;

    @FXML
    private RadioButton checkR2;

    @FXML
    private RadioButton checkR3;

    @FXML
    private RadioButton checkVentas;

    @FXML
    private ToggleGroup departamento;

    @FXML
    private Label lbAcceso;

    @FXML
    private Label lbDNI;

    @FXML
    private Label lbDepartamento;

    @FXML
    private Label lbDireccion;

    @FXML
    private Label lbEmail;

    @FXML
    private Label lbFecha;

    @FXML
    private Label lbNombreApellidos;

    @FXML
    private Label lbPrivilegios;

    @FXML
    private Label lbRol;

    @FXML
    private Label lbTelefono;

    @FXML
    private ToggleGroup nivelAcceso;

    @FXML
    private Pane pAcceso;

    @FXML
    private Pane pCambios;

    @FXML
    private Pane pDatosEmpleado;

    @FXML
    private Pane pDepartamentos;

    @FXML
    private Pane pDireccion;

    @FXML
    private Pane pEditarEmpleado;

    @FXML
    private Pane pEmail;

    @FXML
    private Pane pPrivilegios;

    @FXML
    private Pane pRoles;

    @FXML
    private Pane pTelefono;

    @FXML
    private ToggleGroup roles;

    @FXML
    private TextField tfDireccion;

    @FXML
    private TextField tfEmail;

    @FXML
    private TextField tfTelefono;

    @FXML
    private VBox vBoxDerecho;

    @FXML
    private VBox vBoxIzquierdo;

    @FXML
    private VBox vBoxMedio;

    @FXML
    void OnActionBtnEditarEmpleado(ActionEvent event) {

    }

    @FXML
    void OnActionBtnVolverEditarEmpleado(ActionEvent event) throws IOException {
        HelloApplication.setRoot("ListaEmpleado");
    }

}
