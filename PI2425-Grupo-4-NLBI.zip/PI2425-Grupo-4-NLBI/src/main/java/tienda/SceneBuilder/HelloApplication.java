package tienda.SceneBuilder;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import tienda.Model.Clientes.Cliente;
import tienda.Model.Usuarios.Usuario;
import tienda.dao.ClienteDAO;


//891
//599

import java.io.IOException;

public class HelloApplication extends Application {

    private static Scene scene;

    private static Usuario user;

    public static Usuario getUser() {
        return user;
    }

    public static void setUser(Usuario user) {
        HelloApplication.user = user;
    }

    public static Cliente parseCliente(){
        ClienteDAO dao = new ClienteDAO();
        return dao.obtenerPorId(HelloApplication.getUser().getDni());
    }

    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("Login"), 879, 591);
        stage.setScene(scene);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource( fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }
}